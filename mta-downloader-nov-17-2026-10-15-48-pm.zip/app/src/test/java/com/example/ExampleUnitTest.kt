package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.extractor.MediaExtractorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
    private fun extractor(): MediaExtractorEngine =
        MediaExtractorEngine(ApplicationProvider.getApplicationContext<Context>())

    @Test fun extractsSharedUrlAndStripsArabicSentencePunctuation() {
        assertEquals(
            "https://www.tiktok.com/@mta/video/123456",
            extractor().extractFirstUrlFromSharedText("شاهد: https://www.tiktok.com/@mta/video/123456، الآن")
        )
    }

    @Test fun acceptsBareWwwDomainAndNormalizesScheme() {
        assertEquals("https://www.example.com/video", extractor().extractFirstUrlFromSharedText("www.example.com/video"))
    }

    @Test fun rejectsNonHttpSchemesAndMalformedHostlessUrls() {
        assertNull(extractor().extractFirstUrlFromSharedText("javascript:alert(1)"))
        assertNull(extractor().extractFirstUrlFromSharedText("https:///missing-host"))
    }

    @Test fun platformMatchingUsesHostnameBoundaries() {
        assertEquals("YouTube", extractor().detectPlatformName("https://m.youtube.com/watch?v=abc"))
        assertEquals("الويب", extractor().detectPlatformName("https://notyoutube.com/watch?v=abc"))
    }
}
