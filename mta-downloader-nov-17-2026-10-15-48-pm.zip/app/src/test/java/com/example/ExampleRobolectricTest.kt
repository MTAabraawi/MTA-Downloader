package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.extractor.MediaExtractorEngine
import com.example.data.repository.VideoCatalogRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name and StartIo App ID match MTA Downloader specification`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MTA Downloader", appName)
        assertEquals("210745939", MTADownloaderApp.STARTIO_APP_ID)
    }

    @Test
    fun `catalog and media extractor engine parse shared URLs and platforms`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = VideoCatalogRepository()
        assertTrue(repo.getFeaturedVideos().isNotEmpty())
        assertTrue(repo.supportedSites.any { it.name == "YouTube" })

        val extractor = MediaExtractorEngine(context)
        val extracted = extractor.extractFirstUrlFromSharedText(
            "شاهد هذا الفيديو الرائع: https://www.tiktok.com/@mta/video/123456 عبر تيك توك"
        )
        assertEquals("https://www.tiktok.com/@mta/video/123456", extracted)
        assertEquals("TikTok", extractor.detectPlatformName(extracted!!))
    }
}
