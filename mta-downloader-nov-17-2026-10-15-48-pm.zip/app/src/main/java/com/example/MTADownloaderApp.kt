package com.example

import android.app.Application
import com.example.data.extractor.MediaExtractorEngine
import com.example.data.local.AppDatabase
import com.example.data.repository.DownloadRepository
import com.example.data.repository.VideoCatalogRepository
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK

class MTADownloaderApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    val downloadRepository: DownloadRepository by lazy {
        DownloadRepository(
            context = applicationContext,
            downloadDao = database.downloadDao()
        )
    }

    val videoCatalogRepository: VideoCatalogRepository by lazy {
        VideoCatalogRepository()
    }

    val mediaExtractorEngine: MediaExtractorEngine by lazy {
        MediaExtractorEngine(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        // Initialize Start.io (StartApp) SDK with MTA Technologies App ID: 210745939
        StartAppSDK.initParams(this, STARTIO_APP_ID)
            .setReturnAdsEnabled(false)
            .init()
        StartAppAd.disableSplash()
    }

    companion object {
        const val STARTIO_APP_ID = "210745939"
    }
}
