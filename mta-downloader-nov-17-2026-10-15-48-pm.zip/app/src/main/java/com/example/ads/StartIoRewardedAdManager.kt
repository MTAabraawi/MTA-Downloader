package com.example.ads

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.startapp.sdk.adsbase.adlisteners.VideoListener

/**
 * Manages Start.io (StartApp) Rewarded Video ads.
 * Enforces strict gating: download callback fires ONLY inside VideoListener.onVideoCompleted().
 */
class StartIoRewardedAdManager {

    private val mainHandler = Handler(Looper.getMainLooper())

    fun showRewardedVideoForDownload(
        activity: Activity,
        onLoadingStarted: () -> Unit,
        onLoadingFinished: () -> Unit,
        onVideoCompletedRewardEarned: () -> Unit,
        onAdNotCompletedOrFailed: (String) -> Unit
    ) {
        onLoadingStarted()

        val rewardedAd = StartAppAd(activity)
        var rewardCompleted = false
        var terminalCallbackSent = false

        fun notifyFailureOnce(reason: String) {
            if (!terminalCallbackSent) {
                terminalCallbackSent = true
                mainHandler.post {
                    onLoadingFinished()
                    onAdNotCompletedOrFailed(reason)
                }
            }
        }

        // Strict VideoListener: download begins ONLY when onVideoCompleted() is invoked by Start.io SDK.
        rewardedAd.setVideoListener(object : VideoListener {
            override fun onVideoCompleted() {
                Log.d(TAG, "Start.io Rewarded Video onVideoCompleted triggered")
                if (!rewardCompleted) {
                    rewardCompleted = true
                    terminalCallbackSent = true
                    mainHandler.post {
                        onLoadingFinished()
                        onVideoCompletedRewardEarned()
                    }
                }
            }
        })

        rewardedAd.loadAd(
            StartAppAd.AdMode.REWARDED_VIDEO,
            object : AdEventListener {
                override fun onReceiveAd(ad: Ad) {
                    Log.d(TAG, "Start.io Rewarded Video received, displaying now")
                    mainHandler.post {
                        onLoadingFinished()
                        val shown = rewardedAd.showAd(object : AdDisplayListener {
                            override fun adHidden(ad: Ad) {
                                Log.d(TAG, "Start.io Rewarded Ad hidden. rewardCompleted=$rewardCompleted")
                                if (!rewardCompleted) {
                                    notifyFailureOnce("لم تكتمل مشاهدة إعلان المكافأة، لذلك لم يبدأ التحميل.")
                                }
                            }

                            override fun adDisplayed(ad: Ad) {
                                Log.d(TAG, "Start.io Rewarded Ad displayed")
                            }

                            override fun adClicked(ad: Ad) {
                                Log.d(TAG, "Start.io Rewarded Ad clicked")
                            }

                            override fun adNotDisplayed(ad: Ad) {
                                Log.w(TAG, "Start.io Rewarded Ad not displayed: ${ad.errorMessage}")
                                notifyFailureOnce("تعذر عرض إعلان المكافأة حالياً. حاول مرة أخرى.")
                            }
                        })
                        if (!shown) {
                            notifyFailureOnce("تعذر تشغيل نافذة إعلان المكافأة. يرجى المحاولة مجدداً.")
                        }
                    }
                }

                override fun onFailedToReceiveAd(ad: Ad?) {
                    val err = ad?.errorMessage ?: "No ad fill"
                    Log.w(TAG, "Start.io Rewarded Video failed to load: $err")
                    notifyFailureOnce("تعذر تحميل إعلان المكافأة حالياً ($err). تحقق من الاتصال بالإنترنت وحاول مرة أخرى.")
                }
            }
        )
    }

    companion object {
        private const val TAG = "StartIoRewardedAd"
    }
}
