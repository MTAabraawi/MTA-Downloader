package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val systemDownloadId: Long,
    val title: String,
    val sourceUrl: String,
    val sourcePlatform: String,
    val qualityLabel: String,
    val format: String,
    val fileName: String,
    val localUri: String? = null,
    val status: String = DownloadStatus.QUEUED.name,
    val progress: Int = 0,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val thumbnailUrl: String? = null,
    val thumbnailResId: Int? = null,
    val createdAt: Long = System.currentTimeMillis()
)
