package com.example.data.repository

import com.example.R
import com.example.data.model.DetectedMediaStream
import com.example.data.model.QualityOption
import com.example.data.model.SupportedSite
import com.example.data.model.VideoItem

class VideoCatalogRepository {

    val categories: List<String> = listOf(
        "الكل",
        "رائج الآن",
        "تقنية",
        "موسيقى",
        "ألعاب",
        "سينما",
        "وثائقيات"
    )

    val supportedSites: List<SupportedSite> = listOf(
        SupportedSite(
            id = "youtube",
            name = "YouTube",
            url = "https://m.youtube.com",
            badgeColorHex = 0xFFFF0033,
            tag = "فيديو 4K"
        ),
        SupportedSite(
            id = "tiktok",
            name = "TikTok",
            url = "https://www.tiktok.com",
            badgeColorHex = 0xFF00F2EA,
            tag = "بدون علامة"
        ),
        SupportedSite(
            id = "instagram",
            name = "Instagram",
            url = "https://www.instagram.com",
            badgeColorHex = 0xFFE1306C,
            tag = "Reels"
        ),
        SupportedSite(
            id = "facebook",
            name = "Facebook",
            url = "https://m.facebook.com",
            badgeColorHex = 0xFF1877F2,
            tag = "HD"
        ),
        SupportedSite(
            id = "x",
            name = "X / Twitter",
            url = "https://x.com",
            badgeColorHex = 0xFF0099FF,
            tag = "MP4"
        ),
        SupportedSite(
            id = "vimeo",
            name = "Vimeo",
            url = "https://vimeo.com/watch",
            badgeColorHex = 0xFF1AB7EA,
            tag = "Full HD"
        ),
        SupportedSite(
            id = "dailymotion",
            name = "Dailymotion",
            url = "https://www.dailymotion.com",
            badgeColorHex = 0xFF00D2FF,
            tag = "سريع"
        ),
        SupportedSite(
            id = "soundcloud",
            name = "SoundCloud",
            url = "https://m.soundcloud.com",
            badgeColorHex = 0xFFFF5500,
            tag = "MP3"
        )
    )

    fun getFeaturedVideos(): List<VideoItem> = listOf(
        VideoItem(
            id = "v1",
            title = "مراجعة شاملة لأقوى تقنيات الذكاء الاصطناعي والهواتف الذكية 2026",
            channelName = "MTA Tech Arabic",
            channelInitial = "M",
            views = "1.4M مشاهدة",
            publishedAgo = "منذ 3 ساعات",
            duration = "10:34",
            category = "تقنية",
            sourcePlatform = "YouTube",
            thumbnailRes = R.drawable.img_thumb_tech,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            description = "استعراض تقني معمق لأحدث أجهزة العرض والمعالجات بدقة 4K مع سرعة تحميل عالية."
        ),
        VideoItem(
            id = "v2",
            title = "مهرجان الموسيقى الإلكترونية والعروض الضوئية المباشرة — Ultra Neon Live",
            channelName = "Pulse Audio Live",
            channelInitial = "P",
            views = "890K مشاهدة",
            publishedAgo = "منذ يوم واحد",
            duration = "15:20",
            category = "موسيقى",
            sourcePlatform = "Vimeo",
            thumbnailRes = R.drawable.img_thumb_music,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
            description = "حفل موسيقي مباشر بجودة صوت نقية 320kbps وإضاءة نيون مذهلة."
        ),
        VideoItem(
            id = "v3",
            title = "سباقات المستقبل Cyberpunk 2099 — لقطات لعب بدقة 60 إطار/ثانية",
            channelName = "Nexus Gaming HD",
            channelInitial = "N",
            views = "2.1M مشاهدة",
            publishedAgo = "منذ 5 ساعات",
            duration = "08:45",
            category = "ألعاب",
            sourcePlatform = "YouTube",
            thumbnailRes = R.drawable.img_thumb_gaming,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
            description = "أقوى مطاردات الليل في عالم السايبربانك بجودة Full HD وسرعة إطارات ثابتة."
        ),
        VideoItem(
            id = "v4",
            title = "فيلم الرسوم المتحركة القصير Big Buck Bunny — نسخة 1080p الكاملة",
            channelName = "Blender Cinema",
            channelInitial = "B",
            views = "5.8M مشاهدة",
            publishedAgo = "منذ أسبوع",
            duration = "09:56",
            category = "سينما",
            sourcePlatform = "Vimeo",
            thumbnailRes = R.drawable.img_hero_banner,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            description = "عمل سينمائي ثلاثي الأبعاد مفتوح المصدر بجودة فائقة متاح للتحميل الفوري."
        ),
        VideoItem(
            id = "v5",
            title = "رحلة في عالم المؤثرات البصرية والخيال العلمي — Tears of Steel 4K",
            channelName = "Sci-Fi Vault",
            channelInitial = "S",
            views = "3.2M مشاهدة",
            publishedAgo = "منذ 3 أيام",
            duration = "12:14",
            category = "سينما",
            sourcePlatform = "Dailymotion",
            thumbnailRes = R.drawable.img_thumb_tech,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            description = "فيلم خيال علمي قصير يمزج التصوير الواقعي بالخدع السينمائية الاحترافية."
        ),
        VideoItem(
            id = "v6",
            title = "أجمل مغامرات الطبيعة والطرق الجبلية — جولة وثائقية ممتعة",
            channelName = "Horizon Docs",
            channelInitial = "H",
            views = "640K مشاهدة",
            publishedAgo = "منذ يومين",
            duration = "06:18",
            category = "وثائقيات",
            sourcePlatform = "Facebook",
            thumbnailRes = R.drawable.img_thumb_gaming,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
            description = "توثيق مذهل للقيادة في الطرق الوعرة والطبيعة المفتوحة بجودة HD."
        ),
        VideoItem(
            id = "v7",
            title = "إيقاعات نيون وريمكس حصري للاستماع بدون إنترنت",
            channelName = "MTA Beats",
            channelInitial = "M",
            views = "470K مشاهدة",
            publishedAgo = "منذ 12 ساعة",
            duration = "04:52",
            category = "موسيقى",
            sourcePlatform = "SoundCloud",
            thumbnailRes = R.drawable.img_thumb_music,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoy.mp4",
            description = "مقطوعة موسيقية حماسية جاهزة للتحميل بجودة عالية."
        ),
        VideoItem(
            id = "v8",
            title = "أسرار تسريع الشبكات وبناء تطبيقات الموبايل الحديثة",
            channelName = "MTA Technologies",
            channelInitial = "M",
            views = "980K مشاهدة",
            publishedAgo = "منذ 4 أيام",
            duration = "14:05",
            category = "تقنية",
            sourcePlatform = "YouTube",
            thumbnailRes = R.drawable.img_hero_banner,
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
            description = "دليل مطوري MTA Technologies لتحسين سرعة البث وتقليل استهلاك البيانات."
        )
    )

    fun buildFromCapturedBrowserStreams(
        streams: List<DetectedMediaStream>,
        pageTitle: String,
        platform: String
    ): VideoItem {
        val primary = streams.first()
        val qualities = streams.mapIndexed { idx, s ->
            QualityOption(
                id = "captured_$idx",
                label = if (idx == 0) "البث الملتقط الأساسي (${s.formatLabel})" else "بث ملتقط ${idx + 1} (${s.formatLabel})",
                format = s.formatLabel,
                sizeEstimate = "مباشر",
                extension = s.extension,
                mimeType = s.mimeType,
                overrideStreamUrl = s.url
            )
        }
        return VideoItem(
            id = "captured_${System.currentTimeMillis()}",
            title = pageTitle.ifBlank { primary.title },
            channelName = platform,
            channelInitial = platform.firstOrNull()?.uppercase() ?: "M",
            views = "${streams.size} مسار مكتشف",
            publishedAgo = "الآن",
            duration = primary.formatLabel,
            category = "رائج الآن",
            sourcePlatform = platform,
            thumbnailRes = R.drawable.img_hero_banner,
            streamUrl = primary.url,
            description = "تم التقاط بث الوسائط مباشرة من المتصفح الذكي.",
            qualities = qualities
        )
    }
}
