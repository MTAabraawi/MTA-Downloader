package com.example.data.extractor

import android.content.Context
import com.example.R
import com.example.data.model.QualityOption
import com.example.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Locale
import java.util.concurrent.TimeUnit

sealed class MediaExtractionResult {
    data class Success(val videoItem: VideoItem) : MediaExtractionResult()
    data class NeedsSmartBrowser(
        val normalizedUrl: String,
        val platform: String,
        val reason: String
    ) : MediaExtractionResult()
    data class Error(val message: String) : MediaExtractionResult()
}

/**
 * Multi-layer media extractor supporting:
 * 1. Direct media link probing (HEAD/GET Content-Type & Content-Length)
 * 2. On-device public HTML and metadata extraction
 * 3. On-device HTML/OpenGraph/JSON-LD/<video> stream scraping via OkHttp
 * 4. Smart Browser WebView live stream sniffing fallback for JS-rendered platforms
 */
class MediaExtractorEngine(context: Context) {


    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()



    fun extractFirstUrlFromSharedText(rawText: String): String? {
        val urlRegex = Regex("""(?i)https?://[^\s<>"'\]\)]+""")
        val candidate = urlRegex.find(rawText.trim())?.value
            ?: rawText.trim().takeIf { it.contains('.') && !it.any(Char::isWhitespace) }?.let {
                if (it.startsWith("www.", true)) "https://$it" else "https://$it"
            }
            ?: return null
        val cleaned = candidate.trim().replace(Regex("""[.,;:!?)}\]،؛"']+$"""), "")
        return runCatching {
            val uri = java.net.URI(cleaned)
            val scheme = uri.scheme?.lowercase(Locale.US)
            val host = uri.host
            if (scheme !in setOf("http", "https") || host.isNullOrBlank() || host == "localhost") null
            else cleaned
        }.getOrNull()
    }

    fun detectPlatformName(url: String): String {
        val host = runCatching { java.net.URI(url).host?.lowercase(Locale.US)?.removePrefix("www.") }.getOrNull().orEmpty()
        fun matches(domain: String) = host == domain || host.endsWith(".$domain")
        return when {
            matches("youtube.com") || matches("youtu.be") || matches("youtube-nocookie.com") -> "YouTube"
            matches("tiktok.com") -> "TikTok"
            matches("instagram.com") -> "Instagram"
            matches("facebook.com") || matches("fb.watch") -> "Facebook"
            matches("vimeo.com") -> "Vimeo"
            matches("dailymotion.com") || matches("dai.ly") -> "Dailymotion"
            matches("x.com") || matches("twitter.com") -> "X / Twitter"
            matches("soundcloud.com") -> "SoundCloud"
            matches("reddit.com") || matches("v.redd.it") -> "Reddit"
            else -> "الويب"
        }
    }

    suspend fun extractMedia(rawInput: String, customTitle: String? = null): MediaExtractionResult =
        withContext(Dispatchers.IO) {
            val normalizedUrl = extractFirstUrlFromSharedText(rawInput)
                ?: return@withContext MediaExtractionResult.Error("يرجى إدخال رابط URL صحيح يبدأ بـ http أو https")

            val platform = detectPlatformName(normalizedUrl)

            // Layer 1: Check if the link points directly to a media file (.mp4, .webm, .mp3, .m4a, etc.)
            probeDirectMediaUrl(normalizedUrl, platform, customTitle)?.let { directItem ->
                return@withContext MediaExtractionResult.Success(directItem)
            }

            // Local metadata extraction only. No user-configured third-party extraction server.
            scrapeHtmlForMedia(normalizedUrl, platform, customTitle)?.let { scrapedItem ->
                return@withContext MediaExtractionResult.Success(scrapedItem)
            }

            val reason = "لم يعثر المحرك المحلي على رابط وسائط مباشر قابل للتنزيل من $platform. افتح الصفحة في المتصفح الداخلي وشغّل المحتوى العام؛ سيظهر زر التحميل عند التقاط رابط مباشر مدعوم. قد تمنع المنصة تنزيل بعض المقاطع أو تتطلب استخدام ميزات التنزيل الرسمية."
            MediaExtractionResult.NeedsSmartBrowser(
                normalizedUrl = normalizedUrl,
                platform = platform,
                reason = reason
            )
        }

    private fun probeDirectMediaUrl(
        url: String,
        platform: String,
        customTitle: String?
    ): VideoItem? {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        val hasDirectExt = lower.endsWith(".mp4") || lower.endsWith(".webm") ||
            lower.endsWith(".mov") || lower.endsWith(".m4v") ||
            lower.endsWith(".mp3") || lower.endsWith(".m4a")

        var contentType = ""
        var contentLength = -1L

        // Some CDNs reject HEAD even though a normal media GET is available.
        runCatching {
            val headReq = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", MOBILE_USER_AGENT)
                .build()
            httpClient.newCall(headReq).execute().use { resp ->
                if (resp.isSuccessful || resp.code == 206) {
                    contentType = resp.header("Content-Type").orEmpty().substringBefore(';').trim().lowercase(Locale.US)
                    contentLength = resp.header("Content-Length")?.toLongOrNull()
                        ?: resp.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                        ?: -1L
                }
            }
        }
        if (contentType.isBlank()) {
            runCatching {
                val rangeReq = Request.Builder()
                    .url(url)
                    .get()
                    .header("Range", "bytes=0-0")
                    .header("User-Agent", MOBILE_USER_AGENT)
                    .build()
                httpClient.newCall(rangeReq).execute().use { resp ->
                    contentType = resp.header("Content-Type").orEmpty().substringBefore(';').trim().lowercase(Locale.US)
                    contentLength = resp.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                        ?: resp.header("Content-Length")?.toLongOrNull()
                        ?: -1L
                }
            }
        }
        // Never mistake a login/error HTML page for a downloadable video just because its URL ends in .mp4.
        if (contentType.startsWith("text/html") || contentType.contains("application/json")) return null

        val isAudio = contentType.startsWith("audio/") || lower.endsWith(".mp3") || lower.endsWith(".m4a")
        val isVideo = contentType in setOf("video/mp4", "video/webm", "video/quicktime", "video/x-m4v") ||
            lower.endsWith(".mp4") || lower.endsWith(".webm") || lower.endsWith(".mov") || lower.endsWith(".m4v")

        if (!hasDirectExt && !isAudio && !isVideo) return null

        val sizeLabel = if (contentLength > 0L) {
            String.format(Locale.US, "%.1f MB", contentLength / (1024.0 * 1024.0))
        } else {
            "جاهز"
        }

        val ext = when {
            lower.endsWith(".mp3") || contentType.contains("mpeg") -> "mp3"
            lower.endsWith(".m4a") || contentType.contains("mp4a") || contentType == "audio/mp4" -> "m4a"
            lower.endsWith(".webm") || contentType.contains("webm") -> "webm"
            lower.endsWith(".mov") || contentType.contains("quicktime") -> "mov"
            lower.endsWith(".m4v") -> "m4v"
            else -> "mp4"
        }
        val mime = when {
            isAudio && ext == "m4a" -> "audio/mp4"
            isAudio -> "audio/mpeg"
            ext == "mov" -> "video/quicktime"
            else -> "video/$ext"
        }
        val formatLabel = ext.uppercase(Locale.US)

        val inferredName = url.substringAfterLast("/").substringBefore("?")
            .takeIf { it.isNotBlank() && it.length <= 60 }
            ?: "ملف وسائط من $platform"

        val qualities = listOf(
            QualityOption(
                id = "original",
                label = if (isAudio) "الجودة الأصلية (صوت)" else "الجودة الأصلية ($formatLabel)",
                format = formatLabel,
                sizeEstimate = sizeLabel,
                extension = ext,
                mimeType = mime,
                overrideStreamUrl = url
            )
        )

        return VideoItem(
            id = "direct_${System.currentTimeMillis()}",
            title = customTitle?.takeIf { it.isNotBlank() } ?: inferredName,
            channelName = platform,
            channelInitial = platform.firstOrNull()?.uppercase() ?: "M",
            views = sizeLabel,
            publishedAgo = "الآن",
            duration = formatLabel,
            category = "رائج الآن",
            sourcePlatform = platform,
            thumbnailRes = R.drawable.img_hero_banner,
            streamUrl = url,
            description = "تم التحقق من الرابط المباشر بنجاح ($mime).",
            qualities = qualities
        )
    }

    private fun scrapeHtmlForMedia(
        pageUrl: String,
        platform: String,
        customTitle: String?
    ): VideoItem? {
        return runCatching {
            val request = Request.Builder()
                .url(pageUrl)
                .get()
                .header("User-Agent", MOBILE_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .build()

            val html = httpClient.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching null
                val cType = resp.header("Content-Type").orEmpty()
                if (!cType.contains("text/html", true) && !cType.contains("json", true)) {
                    return@runCatching null
                }
                resp.body?.string()?.take(600_000).orEmpty()
            }

            if (html.isBlank()) return@runCatching null

            val title = customTitle?.takeIf { it.isNotBlank() }
                ?: extractMetaContent(html, "og:title")
                ?: extractHtmlTitle(html)
                ?: "فيديو من $platform"

            val thumbnail = extractMetaContent(html, "og:image")
                ?: extractMetaContent(html, "twitter:image")

            val foundStreams = linkedSetOf<String>()

            // 1. OpenGraph & Twitter video meta tags
            listOf(
                "og:video:secure_url",
                "og:video:url",
                "og:video",
                "twitter:player:stream"
            ).forEach { prop ->
                extractMetaContent(html, prop)?.let { candidate ->
                    val resolved = resolveMediaUrl(pageUrl, candidate)
                    if (isPlayableDirectStream(resolved)) {
                        foundStreams.add(resolved)
                    }
                }
            }

            // 2. HTML5 <video src="..."> and <source src="...">
            val tagSrcRegex = Regex(
                """<(?:video|source)[^>]+src=["']([^"']+)["']""",
                RegexOption.IGNORE_CASE
            )
            tagSrcRegex.findAll(html).forEach { match ->
                val url = resolveMediaUrl(pageUrl, match.groupValues[1])
                if (isPlayableDirectStream(url)) {
                    foundStreams.add(url)
                }
            }

            // 3. JSON-LD contentUrl or embedded direct MP4/M4A URLs in script payloads
            val jsonVideoRegex = Regex(
                """https?:\\/\\/[^"'\s<>]+\.(?:mp4|m4v|webm|mov|mp3|m4a)(?:\?[^"'\s<>]*)?|https?://[^"'\s<>]+\.(?:mp4|m4v|webm|mov|mp3|m4a)(?:\?[^"'\s<>]*)?""",
                RegexOption.IGNORE_CASE
            )
            jsonVideoRegex.findAll(html).take(8).forEach { match ->
                val cleaned = resolveMediaUrl(pageUrl, match.value)
                if (isPlayableDirectStream(cleaned) && !cleaned.contains("preview_empty", true)) {
                    foundStreams.add(cleaned)
                }
            }

            if (foundStreams.isEmpty()) return@runCatching null

            val qualities = foundStreams.mapIndexed { idx, streamUrl ->
                val lower = streamUrl.lowercase(Locale.US).substringBefore("?")
                val isAudio = lower.endsWith(".mp3") || lower.endsWith(".m4a")
                val ext = when {
                    lower.endsWith(".mp3") -> "mp3"
                    lower.endsWith(".m4a") -> "m4a"
                    lower.endsWith(".webm") -> "webm"
                    lower.endsWith(".mov") -> "mov"
                    else -> "mp4"
                }
                val qualityHint = when {
                    streamUrl.contains("1080") -> "1080p Full HD"
                    streamUrl.contains("720") -> "720p HD"
                    streamUrl.contains("480") -> "480p SD"
                    streamUrl.contains("360") -> "360p"
                    isAudio -> "ملف صوتي"
                    idx == 0 -> "الجودة الأساسية"
                    else -> "مسار بديل ${idx + 1}"
                }
                QualityOption(
                    id = "scraped_$idx",
                    label = qualityHint,
                    format = ext.uppercase(Locale.US),
                    sizeEstimate = "مباشر",
                    extension = ext,
                    mimeType = when {
                        isAudio && ext == "m4a" -> "audio/mp4"
                        isAudio -> "audio/mpeg"
                        ext == "mov" -> "video/quicktime"
                        else -> "video/$ext"
                    },
                    overrideStreamUrl = streamUrl,
                    requestHeaders = mapOf("Referer" to pageUrl, "User-Agent" to MOBILE_USER_AGENT)
                )
            }

            VideoItem(
                id = "scraped_${System.currentTimeMillis()}",
                title = title,
                channelName = platform,
                channelInitial = platform.firstOrNull()?.uppercase() ?: "M",
                views = "${qualities.size} جودة متاحة",
                publishedAgo = "الآن",
                duration = "HD",
                category = "رائج الآن",
                sourcePlatform = platform,
                thumbnailRes = if (thumbnail == null) R.drawable.img_hero_banner else null,
                thumbnailUrl = thumbnail,
                streamUrl = qualities.first().overrideStreamUrl ?: foundStreams.first(),
                description = "تم استخراج روابط الوسائط مباشرة من صفحة $platform.",
                qualities = qualities
            )
        }.getOrNull()
    }

    private fun resolveMediaUrl(pageUrl: String, rawUrl: String): String {
        val cleaned = cleanExtractedUrl(rawUrl)
        return runCatching { java.net.URI(pageUrl).resolve(cleaned).toString() }.getOrDefault(cleaned)
    }

    private fun extractMetaContent(html: String, propertyName: String): String? {
        val pattern1 = Regex(
            """<meta[^>]+(?:property|name)=["']${Regex.escape(propertyName)}["'][^>]+content=["']([^"']+)["']""",
            RegexOption.IGNORE_CASE
        )
        val pattern2 = Regex(
            """<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${Regex.escape(propertyName)}["']""",
            RegexOption.IGNORE_CASE
        )
        return (pattern1.find(html) ?: pattern2.find(html))?.groupValues?.getOrNull(1)
            ?.replace("&amp;", "&")
            ?.trim()
    }

    private fun extractHtmlTitle(html: String): String? {
        val match = Regex("""<title[^>]*>(.*?)</title>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(html)
        return match?.groupValues?.getOrNull(1)?.replace(Regex("\\s+"), " ")?.trim()?.take(120)
    }

    private fun cleanExtractedUrl(raw: String): String {
        return raw.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")
            .trim()
    }

    private fun isPlayableDirectStream(url: String): Boolean {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        return lower.startsWith("http") && (
            lower.endsWith(".mp4") || lower.endsWith(".m4v") ||
                lower.endsWith(".webm") || lower.endsWith(".mov") || lower.endsWith(".mp3") ||
                lower.endsWith(".m4a")
            )
    }

    companion object {
        private const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    }
}
