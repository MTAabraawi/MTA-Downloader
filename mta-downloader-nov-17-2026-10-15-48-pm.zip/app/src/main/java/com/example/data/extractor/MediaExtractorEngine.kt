package com.example.data.extractor

import android.content.Context
import android.content.SharedPreferences
import com.example.R
import com.example.data.model.QualityOption
import com.example.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.Locale
import java.util.concurrent.TimeUnit

sealed class MediaExtractionResult {
    data class Success(val videoItem: VideoItem) : MediaExtractionResult()
    data class NeedsSmartBrowser(
        val normalizedUrl: String,
        val platform: String,
        val reason: String
    ) : MediaExtractionResult()
    data class Error(val message: String) : MediaExtractionResult()
}

/**
 * Multi-layer media extractor supporting:
 * 1. Direct media link probing (HEAD/GET Content-Type & Content-Length)
 * 2. Configurable Extractor Backend API (Cobalt / yt-dlp compatible JSON endpoint)
 * 3. On-device HTML/OpenGraph/JSON-LD/<video> stream scraping via OkHttp
 * 4. Smart Browser WebView live stream sniffing fallback for JS-rendered platforms
 */
class MediaExtractorEngine(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    fun getExtractorEndpoint(): String =
        prefs.getString(KEY_EXTRACTOR_ENDPOINT, "")?.trim().orEmpty()

    fun setExtractorEndpoint(url: String) {
        prefs.edit().putString(KEY_EXTRACTOR_ENDPOINT, url.trim()).apply()
    }

    fun extractFirstUrlFromSharedText(rawText: String): String? {
        val urlRegex = Regex("""https?://[^\s<>"'\]\)]+""", RegexOption.IGNORE_CASE)
        val match = urlRegex.find(rawText.trim())
        if (match != null) return match.value
        val trimmed = rawText.trim()
        return if (trimmed.contains(".") && !trimmed.contains(" ")) "https://$trimmed" else null
    }

    fun detectPlatformName(url: String): String = when {
        url.contains("youtube.com", true) || url.contains("youtu.be", true) -> "YouTube"
        url.contains("tiktok.com", true) -> "TikTok"
        url.contains("instagram.com", true) -> "Instagram"
        url.contains("facebook.com", true) || url.contains("fb.watch", true) -> "Facebook"
        url.contains("vimeo.com", true) -> "Vimeo"
        url.contains("dailymotion.com", true) || url.contains("dai.ly", true) -> "Dailymotion"
        url.contains("x.com", true) || url.contains("twitter.com", true) -> "X / Twitter"
        url.contains("soundcloud.com", true) -> "SoundCloud"
        url.contains("reddit.com", true) || url.contains("v.redd.it", true) -> "Reddit"
        else -> "الويب"
    }

    suspend fun extractMedia(rawInput: String, customTitle: String? = null): MediaExtractionResult =
        withContext(Dispatchers.IO) {
            val normalizedUrl = extractFirstUrlFromSharedText(rawInput)
                ?: return@withContext MediaExtractionResult.Error("يرجى إدخال رابط URL صحيح يبدأ بـ http أو https")

            val platform = detectPlatformName(normalizedUrl)

            // Layer 1: Check if the link points directly to a media file (.mp4, .webm, .mp3, .m4a, etc.)
            probeDirectMediaUrl(normalizedUrl, platform, customTitle)?.let { directItem ->
                return@withContext MediaExtractionResult.Success(directItem)
            }

            // Layer 2: If a custom Cobalt / yt-dlp extraction backend API is configured, query it first
            val backendEndpoint = getExtractorEndpoint()
            if (backendEndpoint.isNotBlank()) {
                queryBackendExtractorApi(backendEndpoint, normalizedUrl, platform, customTitle)?.let { apiItem ->
                    return@withContext MediaExtractionResult.Success(apiItem)
                }
            }

            // Layer 3: On-device HTML / OpenGraph / JSON-LD / <video> stream scraping
            scrapeHtmlForMedia(normalizedUrl, platform, customTitle)?.let { scrapedItem ->
                return@withContext MediaExtractionResult.Success(scrapedItem)
            }

            // Layer 4: Protected / JS-heavy page -> recommend opening in built-in Smart Browser sniffer
            val reason = if (backendEndpoint.isBlank()) {
                "تستخدم منصة $platform حماية أو مشغل JavaScript ديناميكي. يمكنك فتح الرابط في المتصفح الذكي لالتقاط بث الفيديو أثناء التشغيل، أو إضافة رابط خادم استخراج (yt-dlp / Cobalt) في الإعدادات."
            } else {
                "لم يتم العثور على رابط مباشر عبر خادم الاستخراج. افتح الصفحة في المتصفح الذكي لالتقاط بث الفيديو أثناء تشغيله."
            }
            MediaExtractionResult.NeedsSmartBrowser(
                normalizedUrl = normalizedUrl,
                platform = platform,
                reason = reason
            )
        }

    private fun probeDirectMediaUrl(
        url: String,
        platform: String,
        customTitle: String?
    ): VideoItem? {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        val hasDirectExt = lower.endsWith(".mp4") || lower.endsWith(".webm") ||
            lower.endsWith(".mov") || lower.endsWith(".m4v") ||
            lower.endsWith(".mp3") || lower.endsWith(".m4a")

        var contentType = ""
        var contentLength = -1L

        runCatching {
            val headReq = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", MOBILE_USER_AGENT)
                .build()
            httpClient.newCall(headReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    contentType = resp.header("Content-Type").orEmpty().lowercase(Locale.US)
                    contentLength = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                }
            }
        }

        val isAudio = contentType.startsWith("audio/") || lower.endsWith(".mp3") || lower.endsWith(".m4a")
        val isVideo = contentType.startsWith("video/") || lower.endsWith(".mp4") ||
            lower.endsWith(".webm") || lower.endsWith(".mov") || lower.endsWith(".m4v")

        if (!hasDirectExt && !isAudio && !isVideo) return null

        val sizeLabel = if (contentLength > 0L) {
            String.format(Locale.US, "%.1f MB", contentLength / (1024.0 * 1024.0))
        } else {
            "جاهز"
        }

        val ext = when {
            lower.endsWith(".mp3") || contentType.contains("mpeg") -> "mp3"
            lower.endsWith(".m4a") || contentType.contains("mp4a") -> "m4a"
            lower.endsWith(".webm") || contentType.contains("webm") -> "webm"
            else -> "mp4"
        }
        val mime = if (isAudio) "audio/mpeg" else "video/$ext"
        val formatLabel = ext.uppercase(Locale.US)

        val inferredName = url.substringAfterLast("/").substringBefore("?")
            .takeIf { it.isNotBlank() && it.length <= 60 }
            ?: "ملف وسائط من $platform"

        val qualities = listOf(
            QualityOption(
                id = "original",
                label = if (isAudio) "الجودة الأصلية (صوت)" else "الجودة الأصلية ($formatLabel)",
                format = formatLabel,
                sizeEstimate = sizeLabel,
                extension = ext,
                mimeType = mime,
                overrideStreamUrl = url
            )
        )

        return VideoItem(
            id = "direct_${System.currentTimeMillis()}",
            title = customTitle?.takeIf { it.isNotBlank() } ?: inferredName,
            channelName = platform,
            channelInitial = platform.firstOrNull()?.uppercase() ?: "M",
            views = sizeLabel,
            publishedAgo = "الآن",
            duration = formatLabel,
            category = "رائج الآن",
            sourcePlatform = platform,
            thumbnailRes = R.drawable.img_hero_banner,
            streamUrl = url,
            description = "تم التحقق من الرابط المباشر بنجاح ($mime).",
            qualities = qualities
        )
    }

    private fun queryBackendExtractorApi(
        endpoint: String,
        targetUrl: String,
        platform: String,
        customTitle: String?
    ): VideoItem? {
        return runCatching {
            val normalizedEndpoint = if (endpoint.startsWith("http://") || endpoint.startsWith("https://")) {
                endpoint
            } else {
                "https://$endpoint"
            }

            // Cobalt / Universal JSON payload
            val payload = """{"url":"${targetUrl.replace("\"", "\\\"")}","videoQuality":"1080"}"""
            val request = Request.Builder()
                .url(normalizedEndpoint)
                .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .header("Accept", "application/json")
                .header("User-Agent", MOBILE_USER_AGENT)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@runCatching null
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) return@runCatching null

                val root = json.parseToJsonElement(body).jsonObject
                parseExtractorJsonResponse(root, targetUrl, platform, customTitle)
            }
        }.getOrNull()
    }

    private fun parseExtractorJsonResponse(
        root: JsonObject,
        originalUrl: String,
        platform: String,
        customTitle: String?
    ): VideoItem? {
        val title = customTitle?.takeIf { it.isNotBlank() }
            ?: root["filename"]?.jsonPrimitive?.contentOrNull
            ?: root["title"]?.jsonPrimitive?.contentOrNull
            ?: "فيديو مستخرج من $platform"

        val thumb = root["thumbnail"]?.jsonPrimitive?.contentOrNull
        val qualities = mutableListOf<QualityOption>()

        // 1. Standard Cobalt single stream ("url")
        val directUrl = root["url"]?.jsonPrimitive?.contentOrNull
        if (!directUrl.isNullOrBlank() && directUrl.startsWith("http")) {
            qualities.add(
                QualityOption(
                    id = "best",
                    label = "أعلى جودة متاحة",
                    format = "MP4",
                    sizeEstimate = "HD",
                    extension = "mp4",
                    mimeType = "video/mp4",
                    overrideStreamUrl = directUrl
                )
            )
        }

        // 2. Cobalt picker array or generic "formats" array
        val picker: JsonArray? = root["picker"] as? JsonArray ?: root["formats"] as? JsonArray
        picker?.forEachIndexed { idx, el ->
            val obj = el as? JsonObject ?: return@forEachIndexed
            val streamUrl = obj["url"]?.jsonPrimitive?.contentOrNull ?: return@forEachIndexed
            if (!streamUrl.startsWith("http")) return@forEachIndexed
            val label = obj["quality"]?.jsonPrimitive?.contentOrNull
                ?: obj["label"]?.jsonPrimitive?.contentOrNull
                ?: obj["type"]?.jsonPrimitive?.contentOrNull
                ?: "جودة ${idx + 1}"
            val isAudio = obj["type"]?.jsonPrimitive?.contentOrNull?.contains("audio", true) == true ||
                label.contains("audio", true) || label.contains("mp3", true)
            qualities.add(
                QualityOption(
                    id = "api_$idx",
                    label = label,
                    format = if (isAudio) "MP3" else "MP4",
                    sizeEstimate = "مستخرج",
                    extension = if (isAudio) "mp3" else "mp4",
                    mimeType = if (isAudio) "audio/mpeg" else "video/mp4",
                    overrideStreamUrl = streamUrl
                )
            )
        }

        if (qualities.isEmpty()) return null
        val primaryStream = qualities.first().overrideStreamUrl ?: return null

        return VideoItem(
            id = "api_${System.currentTimeMillis()}",
            title = title,
            channelName = platform,
            channelInitial = platform.firstOrNull()?.uppercase() ?: "M",
            views = "مستخرج عبر API",
            publishedAgo = "الآن",
            duration = "HD",
            category = "رائج الآن",
            sourcePlatform = platform,
            thumbnailRes = if (thumb == null) R.drawable.img_hero_banner else null,
            thumbnailUrl = thumb,
            streamUrl = primaryStream,
            description = "تم استخراج روابط التحميل بنجاح من $originalUrl",
            qualities = qualities.distinctBy { it.overrideStreamUrl }
        )
    }

    private fun scrapeHtmlForMedia(
        pageUrl: String,
        platform: String,
        customTitle: String?
    ): VideoItem? {
        return runCatching {
            val request = Request.Builder()
                .url(pageUrl)
                .get()
                .header("User-Agent", MOBILE_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .build()

            val html = httpClient.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching null
                val cType = resp.header("Content-Type").orEmpty()
                if (!cType.contains("text/html", true) && !cType.contains("json", true)) {
                    return@runCatching null
                }
                resp.body?.string()?.take(600_000).orEmpty()
            }

            if (html.isBlank()) return@runCatching null

            val title = customTitle?.takeIf { it.isNotBlank() }
                ?: extractMetaContent(html, "og:title")
                ?: extractHtmlTitle(html)
                ?: "فيديو من $platform"

            val thumbnail = extractMetaContent(html, "og:image")
                ?: extractMetaContent(html, "twitter:image")

            val foundStreams = linkedSetOf<String>()

            // 1. OpenGraph & Twitter video meta tags
            listOf(
                "og:video:secure_url",
                "og:video:url",
                "og:video",
                "twitter:player:stream"
            ).forEach { prop ->
                extractMetaContent(html, prop)?.let { candidate ->
                    if (isPlayableDirectStream(candidate)) {
                        foundStreams.add(cleanExtractedUrl(candidate))
                    }
                }
            }

            // 2. HTML5 <video src="..."> and <source src="...">
            val tagSrcRegex = Regex(
                """<(?:video|source)[^>]+src=["'](https?://[^"']+)["']""",
                RegexOption.IGNORE_CASE
            )
            tagSrcRegex.findAll(html).forEach { match ->
                val url = cleanExtractedUrl(match.groupValues[1])
                if (isPlayableDirectStream(url)) {
                    foundStreams.add(url)
                }
            }

            // 3. JSON-LD contentUrl or embedded direct MP4/M4A URLs in script payloads
            val jsonVideoRegex = Regex(
                """https?:\\/\\/[^"'\s<>]+\.(?:mp4|m4v|webm|mp3|m4a)(?:\?[^"'\s<>]*)?|https?://[^"'\s<>]+\.(?:mp4|m4v|webm|mp3|m4a)(?:\?[^"'\s<>]*)?""",
                RegexOption.IGNORE_CASE
            )
            jsonVideoRegex.findAll(html).take(8).forEach { match ->
                val cleaned = cleanExtractedUrl(match.value)
                if (!cleaned.contains("preview_empty", true)) {
                    foundStreams.add(cleaned)
                }
            }

            if (foundStreams.isEmpty()) return@runCatching null

            val qualities = foundStreams.mapIndexed { idx, streamUrl ->
                val lower = streamUrl.lowercase(Locale.US).substringBefore("?")
                val isAudio = lower.endsWith(".mp3") || lower.endsWith(".m4a")
                val ext = when {
                    lower.endsWith(".mp3") -> "mp3"
                    lower.endsWith(".m4a") -> "m4a"
                    lower.endsWith(".webm") -> "webm"
                    else -> "mp4"
                }
                val qualityHint = when {
                    streamUrl.contains("1080") -> "1080p Full HD"
                    streamUrl.contains("720") -> "720p HD"
                    streamUrl.contains("480") -> "480p SD"
                    streamUrl.contains("360") -> "360p"
                    isAudio -> "ملف صوتي"
                    idx == 0 -> "الجودة الأساسية"
                    else -> "مسار بديل ${idx + 1}"
                }
                QualityOption(
                    id = "scraped_$idx",
                    label = qualityHint,
                    format = ext.uppercase(Locale.US),
                    sizeEstimate = "مباشر",
                    extension = ext,
                    mimeType = if (isAudio) "audio/mpeg" else "video/$ext",
                    overrideStreamUrl = streamUrl
                )
            }

            VideoItem(
                id = "scraped_${System.currentTimeMillis()}",
                title = title,
                channelName = platform,
                channelInitial = platform.firstOrNull()?.uppercase() ?: "M",
                views = "${qualities.size} جودة متاحة",
                publishedAgo = "الآن",
                duration = "HD",
                category = "رائج الآن",
                sourcePlatform = platform,
                thumbnailRes = if (thumbnail == null) R.drawable.img_hero_banner else null,
                thumbnailUrl = thumbnail,
                streamUrl = qualities.first().overrideStreamUrl ?: foundStreams.first(),
                description = "تم استخراج روابط الوسائط مباشرة من صفحة $platform.",
                qualities = qualities
            )
        }.getOrNull()
    }

    private fun extractMetaContent(html: String, propertyName: String): String? {
        val pattern1 = Regex(
            """<meta[^>]+(?:property|name)=["']${Regex.escape(propertyName)}["'][^>]+content=["']([^"']+)["']""",
            RegexOption.IGNORE_CASE
        )
        val pattern2 = Regex(
            """<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${Regex.escape(propertyName)}["']""",
            RegexOption.IGNORE_CASE
        )
        return (pattern1.find(html) ?: pattern2.find(html))?.groupValues?.getOrNull(1)
            ?.replace("&amp;", "&")
            ?.trim()
    }

    private fun extractHtmlTitle(html: String): String? {
        val match = Regex("""<title[^>]*>(.*?)</title>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(html)
        return match?.groupValues?.getOrNull(1)?.replace(Regex("\\s+"), " ")?.trim()?.take(120)
    }

    private fun cleanExtractedUrl(raw: String): String {
        return raw.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")
            .trim()
    }

    private fun isPlayableDirectStream(url: String): Boolean {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        return lower.startsWith("http") && (
            lower.endsWith(".mp4") || lower.endsWith(".m4v") ||
                lower.endsWith(".webm") || lower.endsWith(".mp3") ||
                lower.endsWith(".m4a")
            )
    }

    companion object {
        private const val PREFS_NAME = "mta_extractor_prefs"
        private const val KEY_EXTRACTOR_ENDPOINT = "extractor_endpoint_url"
        private const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    }
}
