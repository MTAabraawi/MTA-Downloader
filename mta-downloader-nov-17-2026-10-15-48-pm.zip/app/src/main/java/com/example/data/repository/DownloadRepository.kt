package com.example.data.repository

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.PendingDownloadRequest
import com.example.data.model.QualityOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class DownloadRepository(
    private val context: Context,
    private val downloadDao: DownloadDao
) {
    private val downloadManager: DownloadManager by lazy {
        context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    }

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.observeAllDownloads()

    suspend fun enqueueDownloadAfterReward(
        request: PendingDownloadRequest,
        quality: QualityOption
    ): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val targetStreamUrl = quality.overrideStreamUrl?.takeIf { it.isNotBlank() } ?: request.streamUrl
            val sanitizedName = request.title
                .replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF._ -]"), "_")
                .trim()
                .take(48)
                .ifBlank { "mta_video_${System.currentTimeMillis()}" }
            val fileName = "${sanitizedName}_${quality.id}.${quality.extension}"

            val dmRequest = DownloadManager.Request(Uri.parse(targetStreamUrl)).apply {
                setTitle(request.title)
                setDescription("MTA Downloader • ${quality.label}")
                setMimeType(quality.mimeType)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "MTA_Downloader/$fileName"
                )
            }

            val systemId = downloadManager.enqueue(dmRequest)
            val entity = DownloadEntity(
                systemDownloadId = systemId,
                title = request.title,
                sourceUrl = targetStreamUrl,
                sourcePlatform = request.sourcePlatform,
                qualityLabel = quality.label,
                format = quality.format,
                fileName = fileName,
                status = DownloadStatus.DOWNLOADING.name,
                progress = 0,
                thumbnailUrl = request.thumbnailUrl,
                thumbnailResId = request.thumbnailRes
            )
            downloadDao.insert(entity)
        }
    }

    suspend fun syncActiveDownloadsProgress(): Boolean = withContext(Dispatchers.IO) {
        val active = downloadDao.getActiveDownloads()
        if (active.isEmpty()) return@withContext false

        val ids = active.map { it.systemDownloadId }.filter { it > 0L }.toLongArray()
        if (ids.isEmpty()) return@withContext false

        val query = DownloadManager.Query().setFilterById(*ids)
        val cursor = downloadManager.query(query)
        val updatedIds = mutableSetOf<Long>()

        cursor?.use { c ->
            val idIdx = c.getColumnIndex(DownloadManager.COLUMN_ID)
            val statusIdx = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val bytesIdx = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val totalIdx = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val localUriIdx = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

            while (c.moveToNext()) {
                val sysId = if (idIdx >= 0) c.getLong(idIdx) else continue
                updatedIds.add(sysId)
                val entity = active.firstOrNull { it.systemDownloadId == sysId } ?: continue

                val dmStatus = if (statusIdx >= 0) c.getInt(statusIdx) else DownloadManager.STATUS_RUNNING
                val downloaded = if (bytesIdx >= 0) c.getLong(bytesIdx).coerceAtLeast(0L) else 0L
                val total = if (totalIdx >= 0) c.getLong(totalIdx).coerceAtLeast(0L) else 0L
                val localUri = if (localUriIdx >= 0) c.getString(localUriIdx) else entity.localUri

                val mappedStatus = when (dmStatus) {
                    DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.COMPLETED
                    DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                    DownloadManager.STATUS_PENDING -> DownloadStatus.QUEUED
                    else -> DownloadStatus.DOWNLOADING
                }

                val progress = when {
                    mappedStatus == DownloadStatus.COMPLETED -> 100
                    total > 0L -> ((downloaded * 100L) / total).toInt().coerceIn(0, 99)
                    else -> entity.progress
                }

                downloadDao.update(
                    entity.copy(
                        status = mappedStatus.name,
                        progress = progress,
                        downloadedBytes = downloaded,
                        totalBytes = total,
                        localUri = localUri
                    )
                )
            }
        }

        for (entity in active) {
            if (entity.systemDownloadId !in updatedIds) {
                downloadDao.update(entity.copy(status = DownloadStatus.FAILED.name))
            }
        }

        return@withContext true
    }

    suspend fun deleteDownload(entity: DownloadEntity) = withContext(Dispatchers.IO) {
        if (entity.systemDownloadId > 0L) {
            runCatching { downloadManager.remove(entity.systemDownloadId) }
        }
        downloadDao.deleteById(entity.id)
    }
}
