package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.model.DownloadStatus
import com.example.ui.MainViewModel
import com.example.ui.components.AdFailureDialog
import com.example.ui.components.AdLoadingOverlayDialog
import com.example.ui.components.InAppVideoPlayerDialog
import com.example.ui.components.RewardDownloadConfirmDialog
import com.example.ui.components.SmartBrowserFallbackDialog
import com.example.ui.components.UrlAnalyzingOverlayDialog
import com.example.ui.navigation.BrowserRoute
import com.example.ui.navigation.DownloadsRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.screens.BrowserScreen
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MtaCyanGlow
import com.example.ui.theme.MtaDarkNavy
import com.example.ui.theme.MtaDownloaderTheme
import com.example.ui.theme.MtaNeonBlue
import com.example.ui.theme.MtaSurfaceNavy
import com.example.ui.theme.MtaTextSecondary

class MainActivity : ComponentActivity() {

    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as MTADownloaderApp
        val factory = MainViewModel.Factory(
            catalogRepository = app.videoCatalogRepository,
            downloadRepository = app.downloadRepository,
            mediaExtractorEngine = app.mediaExtractorEngine
        )
        mainViewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        handleIncomingShareIntent(intent)

        setContent {
            MtaDownloaderTheme {
                MtaDownloaderRoot(
                    activity = this,
                    viewModel = mainViewModel
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingShareIntent(intent)
    }

    private fun handleIncomingShareIntent(intent: Intent?) {
        if (!::mainViewModel.isInitialized || intent == null) return

        val sharedText = when (intent.action) {
            Intent.ACTION_SEND -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            Intent.ACTION_SEND_MULTIPLE -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                ?: intent.getParcelableArrayListExtra<android.net.Uri>(Intent.EXTRA_STREAM)?.firstOrNull()?.toString()
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }

        if (!sharedText.isNullOrBlank()) {
            mainViewModel.handleSharedTextFromExternalApp(sharedText)
        }
    }
}

@Composable
private fun MtaDownloaderRoot(
    activity: ComponentActivity,
    viewModel: MainViewModel
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val videos by viewModel.filteredVideos.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val browserState by viewModel.browserState.collectAsStateWithLifecycle()
    val rewardDialogState by viewModel.rewardDialogState.collectAsStateWithLifecycle()
    val isAnalyzingUrl by viewModel.isAnalyzingUrl.collectAsStateWithLifecycle()
    val smartBrowserFallback by viewModel.smartBrowserFallback.collectAsStateWithLifecycle()
    val activePlayerMedia by viewModel.activePlayerMedia.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val activeDownloadsCount = remember(downloads) {
        downloads.count {
            it.status == DownloadStatus.DOWNLOADING.name || it.status == DownloadStatus.QUEUED.name
        }
    }

    val isHomeSelected = currentDestination?.hasRoute<HomeRoute>() == true
    val isBrowserSelected = currentDestination?.hasRoute<BrowserRoute>() == true
    val isDownloadsSelected = currentDestination?.hasRoute<DownloadsRoute>() == true

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = false
            }
            launchSingleTop = true
            restoreState = false
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MtaDarkNavy)
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = MtaDarkNavy,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = MtaSurfaceNavy,
                        tonalElevation = 8.dp,
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        NavigationBarItem(
                            selected = isHomeSelected,
                            onClick = { navigateTopLevel(HomeRoute) },
                            icon = {
                                Icon(
                                    imageVector = if (isHomeSelected) Icons.Filled.Home else Icons.Outlined.Home,
                                    contentDescription = stringResource(R.string.nav_home)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_home)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MtaCyanGlow,
                                selectedTextColor = MtaCyanGlow,
                                indicatorColor = MtaNeonBlue.copy(alpha = 0.2f),
                                unselectedIconColor = MtaTextSecondary,
                                unselectedTextColor = MtaTextSecondary
                            ),
                            modifier = Modifier.testTag("nav_home")
                        )
                        NavigationBarItem(
                            selected = isBrowserSelected,
                            onClick = {
                                if (!isBrowserSelected) {
                                    viewModel.showBrowserSitesHome()
                                    navigateTopLevel(BrowserRoute())
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isBrowserSelected) Icons.Filled.Language else Icons.Outlined.Language,
                                    contentDescription = stringResource(R.string.nav_browser)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_browser)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MtaCyanGlow,
                                selectedTextColor = MtaCyanGlow,
                                indicatorColor = MtaNeonBlue.copy(alpha = 0.2f),
                                unselectedIconColor = MtaTextSecondary,
                                unselectedTextColor = MtaTextSecondary
                            ),
                            modifier = Modifier.testTag("nav_browser")
                        )
                        NavigationBarItem(
                            selected = isDownloadsSelected,
                            onClick = { navigateTopLevel(DownloadsRoute) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (activeDownloadsCount > 0) {
                                            Badge(containerColor = MtaNeonBlue) {
                                                Text(
                                                    text = activeDownloadsCount.toString(),
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isDownloadsSelected) Icons.Filled.CloudDownload else Icons.Outlined.CloudDownload,
                                        contentDescription = stringResource(R.string.nav_downloads)
                                    )
                                }
                            },
                            label = { Text(stringResource(R.string.nav_downloads)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MtaCyanGlow,
                                selectedTextColor = MtaCyanGlow,
                                indicatorColor = MtaNeonBlue.copy(alpha = 0.2f),
                                unselectedIconColor = MtaTextSecondary,
                                unselectedTextColor = MtaTextSecondary
                            ),
                            modifier = Modifier.testTag("nav_downloads")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = MtaSurfaceNavy,
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding()
                    ) {
                        NavigationRailItem(
                            selected = isHomeSelected,
                            onClick = { navigateTopLevel(HomeRoute) },
                            icon = {
                                Icon(
                                    imageVector = if (isHomeSelected) Icons.Filled.Home else Icons.Outlined.Home,
                                    contentDescription = stringResource(R.string.nav_home)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_home)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = MtaCyanGlow,
                                selectedTextColor = MtaCyanGlow,
                                indicatorColor = MtaNeonBlue.copy(alpha = 0.22f),
                                unselectedIconColor = MtaTextSecondary,
                                unselectedTextColor = MtaTextSecondary
                            )
                        )
                        NavigationRailItem(
                            selected = isBrowserSelected,
                            onClick = {
                                if (!isBrowserSelected) {
                                    viewModel.showBrowserSitesHome()
                                    navigateTopLevel(BrowserRoute())
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isBrowserSelected) Icons.Filled.Language else Icons.Outlined.Language,
                                    contentDescription = stringResource(R.string.nav_browser)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_browser)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = MtaCyanGlow,
                                selectedTextColor = MtaCyanGlow,
                                indicatorColor = MtaNeonBlue.copy(alpha = 0.22f),
                                unselectedIconColor = MtaTextSecondary,
                                unselectedTextColor = MtaTextSecondary
                            )
                        )
                        NavigationRailItem(
                            selected = isDownloadsSelected,
                            onClick = { navigateTopLevel(DownloadsRoute) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (activeDownloadsCount > 0) {
                                            Badge(containerColor = MtaNeonBlue) {
                                                Text(
                                                    text = activeDownloadsCount.toString(),
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isDownloadsSelected) Icons.Filled.CloudDownload else Icons.Outlined.CloudDownload,
                                        contentDescription = stringResource(R.string.nav_downloads)
                                    )
                                }
                            },
                            label = { Text(stringResource(R.string.nav_downloads)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = MtaCyanGlow,
                                selectedTextColor = MtaCyanGlow,
                                indicatorColor = MtaNeonBlue.copy(alpha = 0.22f),
                                unselectedIconColor = MtaTextSecondary,
                                unselectedTextColor = MtaTextSecondary
                            )
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    NavHost(
                        navController = navController,
                        startDestination = HomeRoute
                    ) {
                        composable<HomeRoute> {
                            HomeScreen(
                                videos = videos,
                                categories = viewModel.categories,
                                selectedCategory = selectedCategory,
                                searchQuery = searchQuery,
                                supportedSites = viewModel.supportedSites,
                                activeDownloadsCount = activeDownloadsCount,
                                onSearchQueryChange = viewModel::updateSearchQuery,
                                onAnalyzeUrlClick = viewModel::analyzeAndRequestUrlDownload,
                                onCategorySelected = viewModel::selectCategory,
                                onSiteClick = { site ->
                                    navigateTopLevel(BrowserRoute(initialUrl = site.url))
                                },
                                onWatchVideoClick = viewModel::openVideoPlayer,
                                onDownloadVideoClick = viewModel::requestVideoDownload,
                                onOpenDownloadsClick = { navigateTopLevel(DownloadsRoute) },
                            )
                        }

                        composable<BrowserRoute> { entry ->
                            val route = entry.toRoute<BrowserRoute>()
                            LaunchedEffect(route.initialUrl) {
                                if (!route.initialUrl.isNullOrBlank()) {
                                    viewModel.openSiteInBrowser(route.initialUrl)
                                }
                            }
                            BrowserScreen(
                                browserState = browserState,
                                supportedSites = viewModel.supportedSites,
                                onAddressChange = viewModel::updateBrowserAddressInput,
                                onAddressSubmit = viewModel::submitBrowserAddress,
                                onSiteSelected = { site -> viewModel.openSiteInBrowser(site.url) },
                                onHomePortalClick = viewModel::showBrowserSitesHome,
                                onPageProgress = viewModel::onBrowserPageProgress,
                                onPageError = viewModel::onBrowserPageError,
                                onMediaDetected = viewModel::onMediaStreamDetected,
                                onDownloadDetectedOrPage = viewModel::requestBrowserDownload
                            )
                        }

                        composable<DownloadsRoute> {
                            DownloadsScreen(
                                downloads = downloads,
                                onPlayDownloaded = viewModel::openDownloadedPlayer,
                                onRetryDownload = viewModel::retryDownload,
                                onDeleteDownload = viewModel::deleteDownload,
                                onExploreVideosClick = { navigateTopLevel(HomeRoute) }
                            )
                        }
                    }
                }
            }
        }
    }

    // URL Analysis Loading Overlay
    if (isAnalyzingUrl) {
        UrlAnalyzingOverlayDialog()
    }

    // Smart Browser Fallback Dialog when a webpage requires JS player rendering or API extractor
    val fallbackPrompt = smartBrowserFallback
    if (fallbackPrompt != null) {
        SmartBrowserFallbackDialog(
            prompt = fallbackPrompt,
            onOpenInSmartBrowser = { url ->
                viewModel.dismissSmartBrowserFallback()
                navigateTopLevel(BrowserRoute(initialUrl = url))
            },
            onDismiss = viewModel::dismissSmartBrowserFallback
        )
    }

    // 1. AlertDialog shown when Download button is tapped (asks user to confirm Start.io Rewarded Video)
    val pending = rewardDialogState.pendingRequest
    if (pending != null) {
        RewardDownloadConfirmDialog(
            pendingRequest = pending,
            selectedQualityIndex = rewardDialogState.selectedQualityIndex,
            onSelectQuality = viewModel::selectQualityIndex,
            onConfirmWatchAd = { viewModel.confirmAndLaunchRewardedAd(activity) },
            onDismiss = viewModel::dismissRewardConfirmationDialog
        )
    }

    // 2. Loading overlay while Start.io loads AdMode.REWARDED_VIDEO
    if (rewardDialogState.isLoadingAd) {
        AdLoadingOverlayDialog()
    }

    // 3. Failure/Incomplete Ad dialog (strictly prevents download if onVideoCompleted didn't fire)
    val adError = rewardDialogState.adErrorMessage
    if (!adError.isNullOrBlank()) {
        AdFailureDialog(
            message = adError,
            onRetry = { viewModel.retryLastRewardedAd(activity) },
            onDismiss = viewModel::dismissAdErrorDialog
        )
    }

    // 4. Built-in Video Player Modal
    val playerMedia = activePlayerMedia
    if (playerMedia != null) {
        InAppVideoPlayerDialog(
            media = playerMedia,
            onDownloadClick = viewModel::requestVideoDownload,
            onDismiss = viewModel::closeVideoPlayer
        )
    }
}
