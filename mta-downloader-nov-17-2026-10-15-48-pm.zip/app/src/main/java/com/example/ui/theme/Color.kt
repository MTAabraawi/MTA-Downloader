package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MTA Technologies Brand Palette
val MtaNeonBlue = Color(0xFF0099FF)
val MtaCyanGlow = Color(0xFF33CCFF)
val MtaElectricBlue = Color(0xFF0066CC)
val MtaDarkNavy = Color(0xFF0A0F1D)
val MtaSurfaceNavy = Color(0xFF11192E)
val MtaSurfaceElevated = Color(0xFF17223B)
val MtaSurfaceHighlight = Color(0xFF1E2D4D)
val MtaBorderSubtle = Color(0xFF233554)
val MtaTextPrimary = Color(0xFFF4F7FC)
val MtaTextSecondary = Color(0xFF94A3B8)
val MtaTextMuted = Color(0xFF64748B)
val MtaSuccessGreen = Color(0xFF00E676)
val MtaWarningAmber = Color(0xFFFFB300)
val MtaErrorRed = Color(0xFFFF5252)
