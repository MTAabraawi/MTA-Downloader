package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Build
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.SupportedSite
import com.example.ui.BrowserState
import com.example.ui.theme.MtaBorderSubtle
import com.example.ui.theme.MtaCyanGlow
import com.example.ui.theme.MtaDarkNavy
import com.example.ui.theme.MtaNeonBlue
import com.example.ui.theme.MtaSuccessGreen
import com.example.ui.theme.MtaSurfaceElevated
import com.example.ui.theme.MtaSurfaceNavy
import com.example.ui.theme.MtaTextPrimary
import com.example.ui.theme.MtaTextSecondary

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    browserState: BrowserState,
    supportedSites: List<SupportedSite>,
    onAddressChange: (String) -> Unit,
    onAddressSubmit: () -> Unit,
    onSiteSelected: (SupportedSite) -> Unit,
    onHomePortalClick: () -> Unit,
    onPageProgress: (String?, String?, Boolean, Int) -> Unit,
    onPageError: (String) -> Unit,
    onMediaDetected: (String, String?, String?) -> Unit,
    onDownloadDetectedOrPage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var lastNavigationVersion by remember { mutableStateOf(Long.MIN_VALUE) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MtaDarkNavy)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Smart Browser Toolbar
            Surface(
                color = MtaSurfaceNavy,
                tonalElevation = 4.dp,
                border = BorderStroke(1.dp, MtaBorderSubtle)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = onHomePortalClick,
                            modifier = Modifier.testTag("browser_home_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Home,
                                contentDescription = "بوابة المواقع",
                                tint = MtaCyanGlow
                            )
                        }

                        OutlinedTextField(
                            value = browserState.addressInput,
                            onValueChange = onAddressChange,
                            placeholder = {
                                Text(
                                    text = "أدخل رابط أي موقع أو ابحث...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MtaTextSecondary,
                                    maxLines = 1
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MtaDarkNavy,
                                unfocusedContainerColor = MtaDarkNavy,
                                focusedBorderColor = MtaNeonBlue,
                                unfocusedBorderColor = MtaBorderSubtle,
                                focusedTextColor = MtaTextPrimary,
                                unfocusedTextColor = MtaTextPrimary
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    focusManager.clearFocus()
                                    onAddressSubmit()
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("browser_url_input")
                        )

                        if (browserState.activeUrl.isNotBlank()) {
                            IconButton(onClick = { webViewRef?.goBack() }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "رجوع",
                                    tint = MtaTextPrimary
                                )
                            }
                            IconButton(onClick = { webViewRef?.goForward() }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "تقدم",
                                    tint = MtaTextPrimary
                                )
                            }
                            IconButton(onClick = { webViewRef?.reload() }) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "تحديث",
                                    tint = MtaCyanGlow
                                )
                            }
                        }
                    }

                    if (browserState.isLoading && browserState.activeUrl.isNotBlank()) {
                        LinearProgressIndicator(
                            progress = { (browserState.progress / 100f).coerceIn(0.05f, 1f) },
                            color = MtaNeonBlue,
                            trackColor = MtaSurfaceElevated,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                        )
                    }
                }
            }

            if (browserState.activeUrl.isBlank()) {
                // VidMate / Snaptube Supported Sites Portal Grid
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Surface(
                            color = MtaSurfaceNavy,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, MtaNeonBlue.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(MtaNeonBlue.copy(alpha = 0.16f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Language,
                                        contentDescription = null,
                                        tint = MtaCyanGlow
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "متصفح التحميل الذكي",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MtaTextPrimary
                                    )
                                    Text(
                                        text = "تصفح أي منصة وشغّل الفيديو ليلتقط المتصفح رابط البث تلقائياً للتحميل.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MtaTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    items(supportedSites, key = { it.id }) { site ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MtaSurfaceNavy),
                            border = BorderStroke(1.dp, MtaBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSiteSelected(site) }
                                .testTag("portal_site_${site.id}")
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape)
                                        .background(Color(site.badgeColorHex).copy(alpha = 0.16f))
                                        .border(
                                            1.5.dp,
                                            Color(site.badgeColorHex).copy(alpha = 0.75f),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = site.name.take(2).uppercase(),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color(site.badgeColorHex),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = site.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MtaTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    color = MtaSurfaceElevated,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = site.tag,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MtaCyanGlow,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Embedded Real WebView with Live DOM MutationObserver + Network Media Sniffer
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.javaScriptCanOpenWindowsAutomatically = false
                            settings.setSupportMultipleWindows(false)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                settings.safeBrowsingEnabled = true
                            }
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true

                            addJavascriptInterface(
                                object {
                                    @JavascriptInterface
                                    fun onVideoFound(src: String, mime: String?) {
                                        if (src.startsWith("http")) {
                                            post { onMediaDetected(src, title, mime) }
                                        }
                                    }
                                },
                                "MTABridge"
                            )

                            setDownloadListener { url, _, _, mimetype, _ ->
                                if (url.startsWith("http")) {
                                    post {
                                        onMediaDetected(url, title, mimetype)
                                        onDownloadDetectedOrPage()
                                    }
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    onPageProgress(
                                        view?.url,
                                        view?.title,
                                        newProgress < 100,
                                        newProgress
                                    )
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(
                                    view: WebView?,
                                    url: String?,
                                    favicon: Bitmap?
                                ) {
                                    onPageProgress(url, view?.title, true, 15)
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: android.webkit.WebResourceError?
                                ) {
                                    if (request?.isForMainFrame == true) {
                                        onPageError("تعذر تحميل الصفحة: خطأ في الاتصال")
                                    }
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val scheme = request?.url?.scheme?.lowercase()
                                    return scheme != "http" && scheme != "https"
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    onPageProgress(url, view?.title, false, 100)
                                    view?.evaluateJavascript(
                                        """
                                        (function() {
                                            function scanMedia() {
                                                var nodes = document.querySelectorAll('video, source, audio');
                                                for (var i = 0; i < nodes.length; i++) {
                                                    var s = nodes[i].currentSrc || nodes[i].src || nodes[i].getAttribute('src');
                                                    if (s && s.indexOf('http') === 0) {
                                                        MTABridge.onVideoFound(s, nodes[i].type || '');
                                                    }
                                                }
                                            }
                                            scanMedia();
                                            if (!window.__mtaObserver) {
                                                window.__mtaObserver = new MutationObserver(function() { scanMedia(); });
                                                window.__mtaObserver.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
                                                setInterval(scanMedia, 2500);
                                            }
                                        })();
                                        """.trimIndent(),
                                        null
                                    )
                                }

                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    val reqUrl = request?.url?.toString().orEmpty()
                                    val accept = request?.requestHeaders?.get("Accept").orEmpty()
                                    val lower = reqUrl.lowercase().substringBefore("?")
                                    if (lower.endsWith(".mp4") ||
                                        lower.endsWith(".m4v") ||
                                        lower.endsWith(".webm") ||
                                        lower.endsWith(".mp3") ||
                                        lower.endsWith(".m4a") ||
                                        accept.contains("video/", true)
                                    ) {
                                        post { onMediaDetected(reqUrl, view?.title, null) }
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }
                            }

                            lastNavigationVersion = browserState.navigationVersion
                            loadUrl(browserState.activeUrl)
                            webViewRef = this
                        }
                    },
                    update = { webView ->
                        webViewRef = webView
                        if (browserState.activeUrl.isNotBlank() &&
                            browserState.navigationVersion != lastNavigationVersion
                        ) {
                            lastNavigationVersion = browserState.navigationVersion
                            webView.loadUrl(browserState.activeUrl)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Neon Floating Download Trigger when browsing a website
        if (browserState.activeUrl.isNotBlank()) {
            val capturedCount = browserState.detectedStreams.size
            val mediaDetected = capturedCount > 0
            ExtendedFloatingActionButton(
                onClick = onDownloadDetectedOrPage,
                containerColor = if (mediaDetected) MtaSuccessGreen else MtaNeonBlue,
                contentColor = if (mediaDetected) MtaDarkNavy else Color.White,
                icon = {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = null
                    )
                },
                text = {
                    Text(
                        text = if (mediaDetected) {
                            "تم التقاط ($capturedCount) • تحميل"
                        } else {
                            "فحص وتحميل الصفحة"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("browser_download_fab")
            )
        }
    }
}
