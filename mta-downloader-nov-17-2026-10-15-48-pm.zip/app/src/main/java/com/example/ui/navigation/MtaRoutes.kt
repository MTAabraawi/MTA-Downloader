package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
data class BrowserRoute(val initialUrl: String? = null)

@Serializable
object DownloadsRoute
