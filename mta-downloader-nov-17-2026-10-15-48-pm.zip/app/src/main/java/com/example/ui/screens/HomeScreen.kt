package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SupportedSite
import com.example.data.model.VideoItem
import com.example.ui.components.YouTubeStyleVideoCard
import com.example.ui.theme.MtaBorderSubtle
import com.example.ui.theme.MtaCyanGlow
import com.example.ui.theme.MtaDarkNavy
import com.example.ui.theme.MtaNeonBlue
import com.example.ui.theme.MtaSurfaceElevated
import com.example.ui.theme.MtaSurfaceNavy
import com.example.ui.theme.MtaTextPrimary
import com.example.ui.theme.MtaTextSecondary

@Composable
fun HomeScreen(
    videos: List<VideoItem>,
    categories: List<String>,
    selectedCategory: String,
    searchQuery: String,
    supportedSites: List<SupportedSite>,
    activeDownloadsCount: Int,
    onSearchQueryChange: (String) -> Unit,
    onAnalyzeUrlClick: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
    onSiteClick: (SupportedSite) -> Unit,
    onWatchVideoClick: (VideoItem) -> Unit,
    onDownloadVideoClick: (VideoItem) -> Unit,
    onOpenDownloadsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MtaDarkNavy)
    ) {
        val columns = if (maxWidth >= 680.dp) 2 else 1

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Brand Header
            item(span = { GridItemSpan(columns) }) {
                MtaBrandHeader(
                    activeDownloadsCount = activeDownloadsCount,
                    onDownloadsBadgeClick = onOpenDownloadsClick,
                )
            }

            // VidMate-style Search / Paste URL Bar
            item(span = { GridItemSpan(columns) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = {
                            Text(
                                text = stringResource(R.string.search_or_paste_hint),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MtaTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                tint = MtaCyanGlow
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(
                                        imageVector = Icons.Filled.Clear,
                                        contentDescription = "مسح",
                                        tint = MtaTextSecondary
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MtaSurfaceNavy,
                            unfocusedContainerColor = MtaSurfaceNavy,
                            focusedBorderColor = MtaNeonBlue,
                            unfocusedBorderColor = MtaBorderSubtle,
                            focusedTextColor = MtaTextPrimary,
                            unfocusedTextColor = MtaTextPrimary,
                            cursorColor = MtaCyanGlow
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                focusManager.clearFocus()
                                if (searchQuery.contains(".") || searchQuery.startsWith("http")) {
                                    onAnalyzeUrlClick(searchQuery)
                                }
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_search_input")
                    )

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            onAnalyzeUrlClick(searchQuery)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MtaNeonBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("analyze_url_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Link,
                            contentDescription = stringResource(R.string.btn_analyze_url),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.btn_analyze_url),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            // Supported Sites Shortcut Row (VidMate / Snaptube Style)
            item(span = { GridItemSpan(columns) }) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "المواقع المدعومة للتحميل السريع",
                        style = MaterialTheme.typography.titleSmall,
                        color = MtaTextPrimary
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        items(supportedSites, key = { it.id }) { site ->
                            SupportedSiteChip(
                                site = site,
                                onClick = { onSiteClick(site) }
                            )
                        }
                    }
                }
            }

            // Featured Hero Banner
            if (searchQuery.isBlank() && selectedCategory == "الكل" && videos.isNotEmpty()) {
                item(span = { GridItemSpan(columns) }) {
                    FeaturedHeroBanner(
                        featuredVideo = videos.first(),
                        onQuickDownload = { onDownloadVideoClick(videos.first()) },
                        onWatchFeatured = { onWatchVideoClick(videos.first()) }
                    )
                }
            }

            // Category Filter Chips (YouTube Feed Style)
            item(span = { GridItemSpan(columns) }) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    items(categories) { category ->
                        val isSelected = category == selectedCategory
                        FilterChip(
                            selected = isSelected,
                            onClick = { onCategorySelected(category) },
                            label = {
                                Text(
                                    text = category,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = MtaSurfaceNavy,
                                labelColor = MtaTextSecondary,
                                selectedContainerColor = MtaNeonBlue,
                                selectedLabelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = MtaBorderSubtle,
                                selectedBorderColor = MtaCyanGlow
                            ),
                            modifier = Modifier
                                .height(40.dp)
                                .testTag("category_chip_$category")
                        )
                    }
                }
            }

            // Section Title
            item(span = { GridItemSpan(columns) }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مكتبة الفيديو الرئيسية",
                        style = MaterialTheme.typography.titleLarge,
                        color = MtaTextPrimary
                    )
                    Text(
                        text = "${videos.size} فيديو متاح",
                        style = MaterialTheme.typography.labelMedium,
                        color = MtaCyanGlow
                    )
                }
            }

            // Empty search result fallback
            if (videos.isEmpty()) {
                item(span = { GridItemSpan(columns) }) {
                    Surface(
                        color = MtaSurfaceNavy,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, MtaBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                tint = MtaNeonBlue,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = "لم يتم العثور على نتائج مطابقة",
                                style = MaterialTheme.typography.titleMedium,
                                color = MtaTextPrimary
                            )
                            Text(
                                text = "يمكنك لصق رابط الفيديو مباشرة والضغط على زر تحليل للتحميل من أي موقع.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MtaTextSecondary
                            )
                        }
                    }
                }
            } else {
                // YouTube-like Video Feed
                items(videos, key = { it.id }) { video ->
                    YouTubeStyleVideoCard(
                        video = video,
                        onWatchClick = onWatchVideoClick,
                        onDownloadClick = onDownloadVideoClick
                    )
                }
            }
        }
    }
}

@Composable
private fun MtaBrandHeader(
    activeDownloadsCount: Int,
    onDownloadsBadgeClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.mta_launcher_icon),
                contentDescription = "شعار MTA Downloader",
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MtaNeonBlue.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            )
            Column {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = MtaTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "by ${stringResource(R.string.brand_company)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MtaCyanGlow
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = MtaSurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (activeDownloadsCount > 0) MtaNeonBlue else MtaBorderSubtle
                ),
                modifier = Modifier
                    .clickable { onDownloadsBadgeClick() }
                    .testTag("header_downloads_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CloudDownload,
                        contentDescription = stringResource(R.string.nav_downloads),
                        tint = MtaNeonBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (activeDownloadsCount > 0) "$activeDownloadsCount نشط" else "التنزيلات",
                        style = MaterialTheme.typography.labelLarge,
                        color = MtaTextPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun SupportedSiteChip(
    site: SupportedSite,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp)
            .testTag("site_shortcut_${site.id}")
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(MtaSurfaceElevated)
                .border(1.5.dp, Color(site.badgeColorHex).copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = site.name.take(2).uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = Color(site.badgeColorHex),
                fontWeight = FontWeight.Bold
            )
        }
        Text(
            text = site.name.substringBefore(" "),
            style = MaterialTheme.typography.bodySmall,
            color = MtaTextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun FeaturedHeroBanner(
    featuredVideo: VideoItem,
    onQuickDownload: () -> Unit,
    onWatchFeatured: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(176.dp)
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, MtaNeonBlue.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
            .clickable { onWatchFeatured() }
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_hero_banner),
            contentDescription = "بانر MTA Downloader",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            MtaDarkNavy.copy(alpha = 0.92f),
                            MtaDarkNavy.copy(alpha = 0.60f),
                            Color.Transparent
                        )
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = MtaNeonBlue.copy(alpha = 0.22f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MtaCyanGlow.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = MtaCyanGlow,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "MTA Turbo Engine • 4K / MP3",
                        style = MaterialTheme.typography.labelSmall,
                        color = MtaCyanGlow
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "حمّل الفيديوهات من جميع المواقع بأعلى جودة",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onQuickDownload,
                        colors = ButtonDefaults.buttonColors(containerColor = MtaNeonBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("hero_download_button")
                    ) {
                        Text(
                            text = "تحميل الفيديو المميز",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    Surface(
                        color = MtaSurfaceElevated.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(40.dp)
                            .clickable { onWatchFeatured() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = MtaCyanGlow,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "معاينة",
                                style = MaterialTheme.typography.labelLarge,
                                color = MtaTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
