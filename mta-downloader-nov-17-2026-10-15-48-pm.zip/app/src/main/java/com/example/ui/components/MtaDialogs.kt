package com.example.ui.components

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.PendingDownloadRequest
import com.example.data.model.PlayerMedia
import com.example.data.model.VideoItem
import com.example.ui.SmartBrowserFallbackPrompt
import com.example.ui.theme.MtaBorderSubtle
import com.example.ui.theme.MtaCyanGlow
import com.example.ui.theme.MtaDarkNavy
import com.example.ui.theme.MtaErrorRed
import com.example.ui.theme.MtaNeonBlue
import com.example.ui.theme.MtaSurfaceElevated
import com.example.ui.theme.MtaSurfaceNavy
import com.example.ui.theme.MtaTextPrimary
import com.example.ui.theme.MtaTextSecondary

@Composable
fun RewardDownloadConfirmDialog(
    pendingRequest: PendingDownloadRequest,
    selectedQualityIndex: Int,
    onSelectQuality: (Int) -> Unit,
    onConfirmWatchAd: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MtaSurfaceNavy,
        tonalElevation = 8.dp,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MtaNeonBlue.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.SmartDisplay,
                    contentDescription = null,
                    tint = MtaCyanGlow,
                    modifier = Modifier.size(30.dp)
                )
            }
        },
        title = {
            Text(
                text = stringResource(R.string.reward_dialog_title),
                style = MaterialTheme.typography.titleLarge,
                color = MtaTextPrimary
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = pendingRequest.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MtaCyanGlow,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Surface(
                    color = MtaSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MtaBorderSubtle)
                ) {
                    Text(
                        text = stringResource(R.string.reward_dialog_message),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MtaTextSecondary,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Text(
                    text = "اختر الجودة والمسار المستخرج:",
                    style = MaterialTheme.typography.labelLarge,
                    color = MtaTextPrimary
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    pendingRequest.qualities.forEachIndexed { index, quality ->
                        val isSelected = index == selectedQualityIndex
                        Surface(
                            color = if (isSelected) MtaNeonBlue.copy(alpha = 0.15f) else MtaSurfaceElevated,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (isSelected) MtaNeonBlue else MtaBorderSubtle
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectQuality(index) }
                                .testTag("quality_option_${quality.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSelectQuality(index) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = MtaNeonBlue,
                                        unselectedColor = MtaTextSecondary
                                    )
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${quality.label} • ${quality.format}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MtaTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = quality.sizeEstimate,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MtaCyanGlow
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmWatchAd,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MtaNeonBlue,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("confirm_reward_ad_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayCircleFilled,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.reward_dialog_confirm),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier
                    .height(48.dp)
                    .testTag("cancel_reward_ad_button")
            ) {
                Text(
                    text = stringResource(R.string.reward_dialog_cancel),
                    color = MtaTextSecondary
                )
            }
        }
    )
}

@Composable
fun UrlAnalyzingOverlayDialog() {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            color = MtaSurfaceNavy,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MtaNeonBlue.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CircularProgressIndicator(color = MtaNeonBlue)
                Text(
                    text = stringResource(R.string.analyzing_url_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = MtaTextPrimary
                )
                Text(
                    text = "فحص الروابط المباشرة والوسائط المضمنة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MtaTextSecondary
                )
            }
        }
    }
}

@Composable
fun SmartBrowserFallbackDialog(
    prompt: SmartBrowserFallbackPrompt,
    onOpenInSmartBrowser: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MtaSurfaceNavy,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Icon(
                imageVector = Icons.Filled.Language,
                contentDescription = null,
                tint = MtaCyanGlow,
                modifier = Modifier.size(34.dp)
            )
        },
        title = {
            Text(
                text = "فتح ${prompt.platform} في المتصفح الذكي",
                style = MaterialTheme.typography.titleLarge,
                color = MtaTextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = prompt.reason,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MtaTextSecondary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onOpenInSmartBrowser(prompt.url) },
                colors = ButtonDefaults.buttonColors(containerColor = MtaNeonBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Text("فتح والتقاط البث")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
                Text("إغلاق", color = MtaTextSecondary)
            }
        }
    )
}

@Composable
fun AdLoadingOverlayDialog() {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            color = MtaSurfaceNavy,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MtaNeonBlue.copy(alpha = 0.5f)),
            tonalElevation = 10.dp
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                CircularProgressIndicator(
                    color = MtaNeonBlue,
                    trackColor = MtaSurfaceElevated,
                    strokeWidth = 3.dp
                )
                Text(
                    text = stringResource(R.string.reward_loading),
                    style = MaterialTheme.typography.titleMedium,
                    color = MtaTextPrimary
                )
                Text(
                    text = "Start.io Rewarded Video • ID: 210745939",
                    style = MaterialTheme.typography.labelMedium,
                    color = MtaTextSecondary
                )
            }
        }
    }
}

@Composable
fun AdFailureDialog(
    message: String,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MtaSurfaceNavy,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Icon(
                imageVector = Icons.Filled.ErrorOutline,
                contentDescription = null,
                tint = MtaErrorRed,
                modifier = Modifier.size(36.dp)
            )
        },
        title = {
            Text(
                text = "تعذر إتمام إعلان المكافأة",
                style = MaterialTheme.typography.titleLarge,
                color = MtaTextPrimary
            )
        },
        text = {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MtaTextSecondary
            )
        },
        confirmButton = {
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = MtaNeonBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("retry_reward_ad_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("إعادة المحاولة")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, MtaBorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Text("إغلاق", color = MtaTextSecondary)
            }
        }
    )
}

@Composable
fun InAppVideoPlayerDialog(
    media: PlayerMedia,
    onDownloadClick: (VideoItem) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            color = MtaDarkNavy,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MtaBorderSubtle)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = media.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MtaTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = media.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MtaCyanGlow,
                            maxLines = 1
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_player_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "إغلاق المشغل",
                            tint = MtaTextPrimary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                val controller = MediaController(ctx)
                                controller.setAnchorView(this)
                                setMediaController(controller)
                                setVideoURI(Uri.parse(media.mediaUrl))
                                setOnPreparedListener { mp ->
                                    mp.isLooping = false
                                    start()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (media.canDownload && media.sourceVideo != null) {
                    Button(
                        onClick = {
                            onDismiss()
                            onDownloadClick(media.sourceVideo)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MtaNeonBlue),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .height(48.dp)
                            .testTag("player_download_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تحميل هذا الفيديو الآن",
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}
