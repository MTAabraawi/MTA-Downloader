package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val MtaDarkColorScheme = darkColorScheme(
    primary = MtaNeonBlue,
    onPrimary = Color.White,
    primaryContainer = MtaElectricBlue,
    onPrimaryContainer = Color.White,
    secondary = MtaCyanGlow,
    onSecondary = MtaDarkNavy,
    secondaryContainer = MtaSurfaceHighlight,
    onSecondaryContainer = MtaCyanGlow,
    tertiary = MtaSuccessGreen,
    onTertiary = MtaDarkNavy,
    background = MtaDarkNavy,
    onBackground = MtaTextPrimary,
    surface = MtaSurfaceNavy,
    onSurface = MtaTextPrimary,
    surfaceVariant = MtaSurfaceElevated,
    onSurfaceVariant = MtaTextSecondary,
    outline = MtaBorderSubtle,
    outlineVariant = MtaSurfaceHighlight,
    error = MtaErrorRed,
    onError = Color.White
)

private val MtaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MtaDownloaderTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MtaDarkColorScheme,
        typography = Typography,
        shapes = MtaShapes,
        content = content
    )
}
