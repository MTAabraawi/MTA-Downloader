package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadStatus
import com.example.ui.theme.MtaBorderSubtle
import com.example.ui.theme.MtaCyanGlow
import com.example.ui.theme.MtaDarkNavy
import com.example.ui.theme.MtaErrorRed
import com.example.ui.theme.MtaNeonBlue
import com.example.ui.theme.MtaSuccessGreen
import com.example.ui.theme.MtaSurfaceElevated
import com.example.ui.theme.MtaSurfaceNavy
import com.example.ui.theme.MtaTextPrimary
import com.example.ui.theme.MtaTextSecondary
import java.util.Locale

private enum class DownloadsFilter(val label: String) {
    ALL("الكل"),
    ACTIVE("جاري التحميل"),
    COMPLETED("مكتمل")
}

@Composable
fun DownloadsScreen(
    downloads: List<DownloadEntity>,
    onPlayDownloaded: (DownloadEntity) -> Unit,
    onRetryDownload: (DownloadEntity) -> Unit,
    onDeleteDownload: (DownloadEntity) -> Unit,
    onExploreVideosClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(DownloadsFilter.ALL) }

    val activeCount = downloads.count {
        it.status == DownloadStatus.DOWNLOADING.name || it.status == DownloadStatus.QUEUED.name
    }
    val completedCount = downloads.count { it.status == DownloadStatus.COMPLETED.name }

    val filtered = remember(downloads, selectedFilter) {
        when (selectedFilter) {
            DownloadsFilter.ALL -> downloads
            DownloadsFilter.ACTIVE -> downloads.filter {
                it.status == DownloadStatus.DOWNLOADING.name ||
                    it.status == DownloadStatus.QUEUED.name ||
                    it.status == DownloadStatus.FAILED.name
            }
            DownloadsFilter.COMPLETED -> downloads.filter {
                it.status == DownloadStatus.COMPLETED.name
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxSize()
            .background(MtaDarkNavy)
    ) {
        // Summary Card
        item {
            Surface(
                color = MtaSurfaceNavy,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, MtaNeonBlue.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "مدير التنزيلات",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MtaTextPrimary
                        )
                        Text(
                            text = "$activeCount نشط • $completedCount مكتمل",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MtaCyanGlow
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MtaNeonBlue.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudDownload,
                            contentDescription = null,
                            tint = MtaNeonBlue,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }

        // Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DownloadsFilter.entries.forEach { filter ->
                    val isSelected = filter == selectedFilter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = MtaSurfaceNavy,
                            labelColor = MtaTextSecondary,
                            selectedContainerColor = MtaNeonBlue,
                            selectedLabelColor = Color.White
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = MtaBorderSubtle,
                            selectedBorderColor = MtaCyanGlow
                        )
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                Surface(
                    color = MtaSurfaceNavy,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MtaBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudDownload,
                            contentDescription = null,
                            tint = MtaNeonBlue,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "لا توجد تنزيلات في هذا القسم بعد",
                            style = MaterialTheme.typography.titleMedium,
                            color = MtaTextPrimary
                        )
                        Text(
                            text = "اختر أي فيديو من المكتبة الرئيسية أو المتصفح واضغط على زر تحميل لبدء التنزيل.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MtaTextSecondary
                        )
                        Button(
                            onClick = onExploreVideosClick,
                            colors = ButtonDefaults.buttonColors(containerColor = MtaNeonBlue),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.Explore, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("استكشاف الفيديوهات")
                        }
                    }
                }
            }
        } else {
            items(filtered, key = { it.id }) { item ->
                DownloadItemCard(
                    item = item,
                    onPlayClick = { onPlayDownloaded(item) },
                    onRetryClick = { onRetryDownload(item) },
                    onDeleteClick = { onDeleteDownload(item) }
                )
            }
        }
    }
}

@Composable
private fun DownloadItemCard(
    item: DownloadEntity,
    onPlayClick: () -> Unit,
    onRetryClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val status = runCatching { DownloadStatus.valueOf(item.status) }
        .getOrDefault(DownloadStatus.DOWNLOADING)

    val statusColor = when (status) {
        DownloadStatus.COMPLETED -> MtaSuccessGreen
        DownloadStatus.FAILED -> MtaErrorRed
        else -> MtaNeonBlue
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MtaSurfaceNavy),
        border = BorderStroke(1.dp, MtaBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("download_item_${item.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(statusColor.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (status) {
                            DownloadStatus.COMPLETED -> Icons.Filled.CheckCircle
                            DownloadStatus.FAILED -> Icons.Filled.ErrorOutline
                            else -> Icons.Filled.CloudDownload
                        },
                        contentDescription = null,
                        tint = statusColor
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = MtaTextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${item.sourcePlatform} • ${item.qualityLabel} • ${item.format}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MtaCyanGlow
                    )
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.testTag("delete_download_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "حذف",
                        tint = MtaTextSecondary
                    )
                }
            }

            if (status == DownloadStatus.DOWNLOADING || status == DownloadStatus.QUEUED) {
                LinearProgressIndicator(
                    progress = { (item.progress / 100f).coerceIn(0.02f, 1f) },
                    color = MtaNeonBlue,
                    trackColor = MtaSurfaceElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val bytesText = if (item.totalBytes > 0L) {
                    "${formatMb(item.downloadedBytes)} / ${formatMb(item.totalBytes)} (${item.progress}%)"
                } else if (status == DownloadStatus.COMPLETED) {
                    "اكتمل التحميل بنجاح"
                } else if (status == DownloadStatus.FAILED) {
                    "تعذر التحميل"
                } else {
                    "جاري التحميل... ${item.progress}%"
                }

                Text(
                    text = bytesText,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (status == DownloadStatus.FAILED) MtaErrorRed else MtaTextSecondary
                )

                when (status) {
                    DownloadStatus.COMPLETED -> {
                        Button(
                            onClick = onPlayClick,
                            colors = ButtonDefaults.buttonColors(containerColor = MtaNeonBlue),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تشغيل", fontWeight = FontWeight.Bold)
                        }
                    }
                    DownloadStatus.FAILED -> {
                        Button(
                            onClick = onRetryClick,
                            colors = ButtonDefaults.buttonColors(containerColor = MtaSurfaceElevated),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = null,
                                tint = MtaCyanGlow,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إعادة", color = MtaCyanGlow)
                        }
                    }
                    else -> Unit
                }
            }
        }
    }
}

private fun formatMb(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return String.format(Locale.US, "%.1f MB", mb)
}
