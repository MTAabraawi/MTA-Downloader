package com.example.ui

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ads.StartIoRewardedAdManager
import com.example.data.extractor.MediaExtractionResult
import com.example.data.extractor.MediaExtractorEngine
import com.example.data.local.DownloadEntity
import com.example.data.model.DetectedMediaStream
import com.example.data.model.DownloadStatus
import com.example.data.model.PendingDownloadRequest
import com.example.data.model.PlayerMedia
import com.example.data.model.QualityOption
import com.example.data.model.SupportedSite
import com.example.data.model.VideoItem
import com.example.data.model.defaultVideoQualities
import com.example.data.repository.DownloadRepository
import com.example.data.repository.VideoCatalogRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class BrowserState(
    val activeUrl: String = "",
    val addressInput: String = "",
    val pageTitle: String = "",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val detectedStreams: List<DetectedMediaStream> = emptyList()
)

data class SmartBrowserFallbackPrompt(
    val url: String,
    val platform: String,
    val reason: String
)

data class RewardDialogState(
    val pendingRequest: PendingDownloadRequest? = null,
    val selectedQualityIndex: Int = 0,
    val isLoadingAd: Boolean = false,
    val adErrorMessage: String? = null,
    val lastAttemptedRequest: PendingDownloadRequest? = null,
    val lastAttemptedQuality: QualityOption? = null
)

class MainViewModel(
    private val catalogRepository: VideoCatalogRepository,
    private val downloadRepository: DownloadRepository,
    private val mediaExtractorEngine: MediaExtractorEngine,
    private val rewardedAdManager: StartIoRewardedAdManager = StartIoRewardedAdManager()
) : ViewModel() {

    private val allVideos: List<VideoItem> = catalogRepository.getFeaturedVideos()
    val categories: List<String> = catalogRepository.categories
    val supportedSites: List<SupportedSite> = catalogRepository.supportedSites

    private val _selectedCategory = MutableStateFlow(categories.first())
    val selectedCategory: StateFlow<String> = _selectedCategory

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val filteredVideos: StateFlow<List<VideoItem>> = combine(
        _selectedCategory,
        _searchQuery
    ) { category, query ->
        allVideos.filter { video ->
            val matchesCategory = category == "الكل" ||
                category == "رائج الآن" ||
                video.category == category
            val trimmed = query.trim()
            val matchesQuery = trimmed.isBlank() ||
                video.title.contains(trimmed, ignoreCase = true) ||
                video.channelName.contains(trimmed, ignoreCase = true) ||
                video.sourcePlatform.contains(trimmed, ignoreCase = true) ||
                video.category.contains(trimmed, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = allVideos
    )

    val downloads: StateFlow<List<DownloadEntity>> = downloadRepository.allDownloads
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _browserState = MutableStateFlow(BrowserState())
    val browserState: StateFlow<BrowserState> = _browserState

    private val _rewardDialogState = MutableStateFlow(RewardDialogState())
    val rewardDialogState: StateFlow<RewardDialogState> = _rewardDialogState

    private val _isAnalyzingUrl = MutableStateFlow(false)
    val isAnalyzingUrl: StateFlow<Boolean> = _isAnalyzingUrl

    private val _smartBrowserFallback = MutableStateFlow<SmartBrowserFallbackPrompt?>(null)
    val smartBrowserFallback: StateFlow<SmartBrowserFallbackPrompt?> = _smartBrowserFallback

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog

    private val _extractorEndpoint = MutableStateFlow(mediaExtractorEngine.getExtractorEndpoint())
    val extractorEndpoint: StateFlow<String> = _extractorEndpoint

    private val _activePlayerMedia = MutableStateFlow<PlayerMedia?>(null)
    val activePlayerMedia: StateFlow<PlayerMedia?> = _activePlayerMedia

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage

    init {
        startDownloadProgressSyncLoop()
    }

    private fun startDownloadProgressSyncLoop() {
        viewModelScope.launch {
            while (isActive) {
                runCatching { downloadRepository.syncActiveDownloadsProgress() }
                delay(900L)
            }
        }
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun handleSharedTextFromExternalApp(sharedText: String) {
        val url = mediaExtractorEngine.extractFirstUrlFromSharedText(sharedText)
        if (url != null) {
            _searchQuery.value = url
            analyzeAndRequestUrlDownload(url)
        } else {
            _snackbarMessage.value = "النص المشارك لا يحتوي على رابط فيديو صالح"
        }
    }

    fun analyzeAndRequestUrlDownload(rawInput: String) {
        if (rawInput.isBlank()) {
            _snackbarMessage.value = "يرجى لصق رابط الفيديو أو الموقع أولاً"
            return
        }
        viewModelScope.launch {
            _isAnalyzingUrl.value = true
            when (val result = mediaExtractorEngine.extractMedia(rawInput)) {
                is MediaExtractionResult.Success -> {
                    _isAnalyzingUrl.value = false
                    requestVideoDownload(result.videoItem)
                }
                is MediaExtractionResult.NeedsSmartBrowser -> {
                    _isAnalyzingUrl.value = false
                    _smartBrowserFallback.value = SmartBrowserFallbackPrompt(
                        url = result.normalizedUrl,
                        platform = result.platform,
                        reason = result.reason
                    )
                }
                is MediaExtractionResult.Error -> {
                    _isAnalyzingUrl.value = false
                    _snackbarMessage.value = result.message
                }
            }
        }
    }

    fun dismissSmartBrowserFallback() {
        _smartBrowserFallback.value = null
    }

    fun openSettingsDialog() {
        _extractorEndpoint.value = mediaExtractorEngine.getExtractorEndpoint()
        _showSettingsDialog.value = true
    }

    fun dismissSettingsDialog() {
        _showSettingsDialog.value = false
    }

    fun saveExtractorEndpoint(endpoint: String) {
        mediaExtractorEngine.setExtractorEndpoint(endpoint)
        _extractorEndpoint.value = mediaExtractorEngine.getExtractorEndpoint()
        _showSettingsDialog.value = false
        _snackbarMessage.value = if (endpoint.isBlank()) {
            "تم مسح رابط خادم الاستخراج والاعتماد على المحرك المحلي"
        } else {
            "تم حفظ رابط خادم الاستخراج بنجاح"
        }
    }

    fun requestVideoDownload(video: VideoItem) {
        _rewardDialogState.update {
            RewardDialogState(
                pendingRequest = PendingDownloadRequest(
                    title = video.title,
                    streamUrl = video.streamUrl,
                    sourcePlatform = video.sourcePlatform,
                    thumbnailUrl = video.thumbnailUrl,
                    thumbnailRes = video.thumbnailRes,
                    qualities = video.qualities
                ),
                selectedQualityIndex = 0
            )
        }
    }

    fun requestBrowserDownload() {
        val state = _browserState.value
        val captured = state.detectedStreams
        if (captured.isNotEmpty()) {
            val platform = mediaExtractorEngine.detectPlatformName(state.activeUrl)
            val videoItem = catalogRepository.buildFromCapturedBrowserStreams(
                streams = captured,
                pageTitle = state.pageTitle,
                platform = platform
            )
            requestVideoDownload(videoItem)
        } else if (state.activeUrl.isNotBlank()) {
            analyzeAndRequestUrlDownload(state.activeUrl)
        }
    }

    fun selectQualityIndex(index: Int) {
        _rewardDialogState.update { it.copy(selectedQualityIndex = index) }
    }

    fun dismissRewardConfirmationDialog() {
        _rewardDialogState.update { it.copy(pendingRequest = null) }
    }

    fun dismissAdErrorDialog() {
        _rewardDialogState.update { it.copy(adErrorMessage = null) }
    }

    fun confirmAndLaunchRewardedAd(activity: Activity) {
        val currentState = _rewardDialogState.value
        val request = currentState.pendingRequest ?: return
        val quality = request.qualities.getOrElse(currentState.selectedQualityIndex) {
            defaultVideoQualities().first()
        }
        launchRewardedAdForRequest(activity, request, quality)
    }

    fun retryLastRewardedAd(activity: Activity) {
        val currentState = _rewardDialogState.value
        val request = currentState.lastAttemptedRequest ?: return
        val quality = currentState.lastAttemptedQuality ?: request.qualities.first()
        launchRewardedAdForRequest(activity, request, quality)
    }

    private fun launchRewardedAdForRequest(
        activity: Activity,
        request: PendingDownloadRequest,
        quality: QualityOption
    ) {
        _rewardDialogState.update {
            it.copy(
                pendingRequest = null,
                adErrorMessage = null,
                lastAttemptedRequest = request,
                lastAttemptedQuality = quality
            )
        }

        rewardedAdManager.showRewardedVideoForDownload(
            activity = activity,
            onLoadingStarted = {
                _rewardDialogState.update { it.copy(isLoadingAd = true) }
            },
            onLoadingFinished = {
                _rewardDialogState.update { it.copy(isLoadingAd = false) }
            },
            onVideoCompletedRewardEarned = {
                // Download starts strictly after Start.io VideoListener.onVideoCompleted()
                viewModelScope.launch {
                    val result = downloadRepository.enqueueDownloadAfterReward(request, quality)
                    result.onSuccess {
                        _snackbarMessage.value = "تمت مشاهدة الإعلان بنجاح! بدأ تحميل ${request.title}"
                    }.onFailure { err ->
                        _snackbarMessage.value = "تعذر بدء التحميل: ${err.localizedMessage ?: "خطأ غير معروف"}"
                    }
                }
            },
            onAdNotCompletedOrFailed = { errorMsg ->
                _rewardDialogState.update {
                    it.copy(
                        isLoadingAd = false,
                        adErrorMessage = errorMsg
                    )
                }
            }
        )
    }

    fun openSiteInBrowser(url: String) {
        val normalized = if (url.startsWith("http://") || url.startsWith("https://")) {
            url
        } else {
            "https://$url"
        }
        _browserState.update {
            it.copy(
                activeUrl = normalized,
                addressInput = normalized,
                detectedStreams = emptyList()
            )
        }
    }

    fun showBrowserSitesHome() {
        _browserState.value = BrowserState()
    }

    fun updateBrowserAddressInput(input: String) {
        _browserState.update { it.copy(addressInput = input) }
    }

    fun submitBrowserAddress() {
        val input = _browserState.value.addressInput.trim()
        if (input.isBlank()) {
            showBrowserSitesHome()
            return
        }
        val target = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${java.net.URLEncoder.encode(input, "UTF-8")}"
        }
        openSiteInBrowser(target)
    }

    fun onBrowserPageProgress(url: String?, title: String?, isLoading: Boolean, progress: Int) {
        _browserState.update { state ->
            val urlChanged = !url.isNullOrBlank() && url != state.activeUrl && isLoading && progress <= 20
            state.copy(
                addressInput = url ?: state.addressInput,
                pageTitle = title ?: state.pageTitle,
                isLoading = isLoading,
                progress = progress,
                detectedStreams = if (urlChanged) emptyList() else state.detectedStreams
            )
        }
    }

    fun onMediaStreamDetected(mediaUrl: String, title: String?, mimeHint: String? = null) {
        if (!mediaUrl.startsWith("http")) return
        val lower = mediaUrl.lowercase(Locale.US).substringBefore("?")
        // Skip HLS segments (.ts) when a main stream or mp4 is available
        if (lower.endsWith(".ts") || lower.endsWith(".m4s")) return

        val isAudio = mimeHint?.startsWith("audio/", true) == true ||
            lower.endsWith(".mp3") || lower.endsWith(".m4a")
        val ext = when {
            lower.endsWith(".mp3") -> "mp3"
            lower.endsWith(".m4a") -> "m4a"
            lower.endsWith(".webm") -> "webm"
            else -> "mp4"
        }
        val formatLabel = ext.uppercase(Locale.US)
        val mime = if (isAudio) "audio/mpeg" else "video/$ext"

        _browserState.update { state ->
            if (state.detectedStreams.any { it.url == mediaUrl }) {
                state
            } else {
                val stream = DetectedMediaStream(
                    url = mediaUrl,
                    title = title?.takeIf { it.isNotBlank() } ?: state.pageTitle.ifBlank { "فيديو ملتقط" },
                    formatLabel = formatLabel,
                    extension = ext,
                    mimeType = mime
                )
                state.copy(detectedStreams = (listOf(stream) + state.detectedStreams).take(10))
            }
        }
    }

    fun openVideoPlayer(video: VideoItem) {
        _activePlayerMedia.value = PlayerMedia(
            title = video.title,
            subtitle = "${video.channelName} • ${video.sourcePlatform}",
            mediaUrl = video.streamUrl,
            canDownload = true,
            sourceVideo = video
        )
    }

    fun openDownloadedPlayer(download: DownloadEntity) {
        val playableUri = download.localUri?.takeIf { it.isNotBlank() } ?: download.sourceUrl
        _activePlayerMedia.value = PlayerMedia(
            title = download.title,
            subtitle = "${download.qualityLabel} • ${download.sourcePlatform}",
            mediaUrl = playableUri,
            canDownload = false,
            sourceVideo = null
        )
    }

    fun closeVideoPlayer() {
        _activePlayerMedia.value = null
    }

    fun deleteDownload(entity: DownloadEntity) {
        viewModelScope.launch {
            downloadRepository.deleteDownload(entity)
            _snackbarMessage.value = "تم حذف الملف من القائمة"
        }
    }

    fun retryDownload(entity: DownloadEntity) {
        val request = PendingDownloadRequest(
            title = entity.title,
            streamUrl = entity.sourceUrl,
            sourcePlatform = entity.sourcePlatform,
            thumbnailUrl = entity.thumbnailUrl,
            thumbnailRes = entity.thumbnailResId,
            qualities = defaultVideoQualities()
        )
        _rewardDialogState.update {
            RewardDialogState(pendingRequest = request, selectedQualityIndex = 0)
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    class Factory(
        private val catalogRepository: VideoCatalogRepository,
        private val downloadRepository: DownloadRepository,
        private val mediaExtractorEngine: MediaExtractorEngine
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(catalogRepository, downloadRepository, mediaExtractorEngine) as T
        }
    }
}
